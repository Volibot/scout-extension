function $(id) { return document.getElementById(id); }

async function refresh() {
  const st = await chrome.storage.local.get(['scoutToken', 'scoutEmail', 'polling', 'logs']);
  // Scout status
  if (st.scoutToken) {
    $('scout-dot').classList.add('ok');
    $('scout-state').textContent = 'Scout: connected' + (st.scoutEmail ? ' (' + st.scoutEmail + ')' : '');
  } else {
    $('scout-dot').classList.remove('ok');
    $('scout-state').textContent = 'Scout: open & log in at scout.volibits.com';
  }
  // Naukri status — logged in if the Resdex session cookie (nauk_at/UNID) exists.
  try {
    const nc = await chrome.cookies.get({ url: 'https://www.naukri.com', name: 'UNID' });
    if (nc && nc.value) {
      $('resdex-dot').classList.add('ok');
      $('resdex-state').textContent = 'Naukri: ready';
    } else {
      $('resdex-dot').classList.remove('ok');
      $('resdex-state').textContent = 'Naukri: log in via RMS launcher';
    }
  } catch (e) {
    $('resdex-state').textContent = 'Naukri: unavailable';
  }
  // LinkedIn status — logged in if JSESSIONID cookie exists.
  try {
    const lc = await chrome.cookies.get({ url: 'https://www.linkedin.com', name: 'JSESSIONID' });
    if (lc && lc.value) {
      $('li-dot').classList.add('ok');
      $('li-state').textContent = 'LinkedIn: ready';
    } else {
      $('li-dot').classList.remove('ok');
      $('li-state').textContent = 'LinkedIn: log into Recruiter';
    }
  } catch (e) {
    $('li-state').textContent = 'LinkedIn: unavailable';
  }
  // Polling toggle
  $('toggle').textContent = st.polling ? 'Stop auto-run' : 'Start auto-run';
  $('toggle').dataset.on = st.polling ? '1' : '';
  // Logs
  $('logs').textContent = (st.logs || []).join('\n');
  $('logs').scrollTop = $('logs').scrollHeight;
}

$('toggle').addEventListener('click', async () => {
  const on = $('toggle').dataset.on === '1';
  await chrome.runtime.sendMessage({ type: on ? 'stop-polling' : 'start-polling' });
  setTimeout(refresh, 300);
});
$('pollnow').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'poll-now' });
  setTimeout(refresh, 800);
});

async function _getLogText() {
  const st = await chrome.storage.local.get(['logs']);
  return (st.logs || []).join('\n');
}
function _flashCopyState(msg) {
  $('copy-state').textContent = msg;
  setTimeout(() => { $('copy-state').textContent = ''; }, 2000);
}
$('copylogs').addEventListener('click', async () => {
  const text = await _getLogText();
  if (!text) { _flashCopyState('No logs yet'); return; }
  try {
    await navigator.clipboard.writeText(text);
    _flashCopyState('Copied ✓');
  } catch (e) {
    const ta = document.createElement('textarea');
    ta.value = text; document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); _flashCopyState('Copied ✓'); }
    catch (e2) { _flashCopyState('Copy failed'); }
    ta.remove();
  }
});
$('downloadlogs').addEventListener('click', async () => {
  const text = await _getLogText();
  if (!text) { _flashCopyState('No logs yet'); return; }
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const blob = new Blob([text], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `scout-agent-logs-${stamp}.txt`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
$('clearlogs').addEventListener('click', async () => {
  await chrome.storage.local.set({ logs: [] });   // log() reads from storage each call
  _flashCopyState('Cleared');
  refresh();
});

// ── Queued jobs (pending / stale from a previous session) ──────────────────
const _srcLabel = { naukri: 'Naukri', linkedin_recruiter: 'Recruiter', create_project: 'Create project' };
function _fmtAge(s) { return s < 60 ? `${s}s` : s < 3600 ? `${Math.floor(s / 60)}m` : `${Math.floor(s / 3600)}h`; }
async function refreshJobs() {
  let jobs = [];
  try { jobs = (await chrome.runtime.sendMessage({ type: 'list-jobs' }))?.jobs || []; } catch (e) {}
  const box = $('jobs-box');
  if (!jobs.length) { box.style.display = 'none'; return; }
  box.style.display = 'block';
  $('jobs-count').textContent = jobs.length;
  $('jobs-list').innerHTML = jobs.map(j =>
    `<div style="padding:2px 0">• <b>${_srcLabel[j.source] || j.source}</b> — ${(j.query || '').slice(0, 32)}` +
    ` <span style="color:#999">(${j.status}, ${_fmtAge(j.age_secs)} ago)</span></div>`).join('');
}
$('canceljobs').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'cancel-jobs' });
  refreshJobs();
  setTimeout(refresh, 300);
});

refresh();
refreshJobs();
setInterval(refresh, 2000);
setInterval(refreshJobs, 4000);
