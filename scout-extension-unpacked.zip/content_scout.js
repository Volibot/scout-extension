// Runs on scout.volibits.com — picks up the logged-in Scout JWT and base URL so
// the agent can talk to Scout's API as the current recruiter (no manual token).
(function () {
  function pushToken() {
    try {
      const token = localStorage.getItem('ats_token');
      if (token) {
        chrome.runtime.sendMessage({
          type: 'scout-auth',
          token: token,
          base: location.origin,
          email: localStorage.getItem('recruiter_email') || ''
        });
      }
    } catch (e) { /* ignore */ }
  }
  pushToken();
  // Re-push on focus in case the user just logged in.
  window.addEventListener('focus', pushToken);

  // When Scout queues a search/project, poll immediately instead of waiting for
  // the 30s alarm tick. The page dispatches this event on window.
  window.addEventListener('scout-poll-now', function () {
    try { chrome.runtime.sendMessage({ type: 'poll-now' }); } catch (e) { /* ignore */ }
  });
})();
