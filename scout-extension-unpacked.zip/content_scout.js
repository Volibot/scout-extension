// Runs on scout.volibits.com — picks up the logged-in Scout JWT and base URL so
// the agent can talk to Scout's API as the current recruiter (no manual token).
(function () {
  // Mark the page so it knows the Scout extension is installed — lets the page fall back
  // to opening the candidate's public LinkedIn profile directly when it's NOT installed.
  try { document.documentElement.setAttribute('data-scout-ext', '1'); } catch (e) { /* ignore */ }

  function pushToken() {
    try {
      const token = localStorage.getItem('ats_token');
      if (token) {
        chrome.runtime.sendMessage({
          type: 'scout-auth',
          token: token,
          base: location.origin,
          email: localStorage.getItem('recruiter_email') || ''
        });
      }
    } catch (e) { /* ignore */ }
  }
  pushToken();
  // Re-push on focus in case the user just logged in.
  window.addEventListener('focus', pushToken);

  // When Scout queues a search/project, poll immediately instead of waiting for
  // the alarm tick. The page dispatches this event on window.
  window.addEventListener('scout-poll-now', function () {
    try { chrome.runtime.sendMessage({ type: 'poll-now' }); } catch (e) { /* ignore */ }
  });

  // KEEP-ALIVE POLLING: Chrome evicts the MV3 service worker when idle and can throttle its
  // alarms so hard that polling silently stops (jobs never get claimed). An OPEN page/tab is NOT
  // suspended the same way, so drive polling from here: every ~40s poke the worker to poll (it
  // only acts if auto-run is enabled). This makes job pickup reliable as long as a Scout tab is
  // open — which it must be anyway for the login token. Background-tab timer throttling still
  // fires this about once a minute, well within the 15-min job lifetime.
  setInterval(function () {
    try { chrome.runtime.sendMessage({ type: 'tick-if-polling' }); } catch (e) { /* ignore */ }
  }, 40000);

  // Assisted DM: the Scout page posts {source:'scout',type:'open-dm',...}; relay it to
  // the background, which opens the candidate's LinkedIn message box pre-filled.
  window.addEventListener('message', function (e) {
    if (e.source !== window || !e.data || e.data.source !== 'scout' || e.data.type !== 'open-dm') return;
    try {
      chrome.runtime.sendMessage({ type: 'open-dm', url: e.data.url, message: e.data.message, name: e.data.name });
    } catch (err) { /* ignore */ }
  });
})();
