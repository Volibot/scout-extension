// Service worker: stores the Scout auth, polls Scout for pending Naukri jobs,
// runs each search by calling the Resdex JSON API in the page's MAIN world
// (so it's same-origin — custom headers + cookies pass, unlike a content-script
// fetch which Resdex's CORS would strip), and posts results back to Scout.

const DEFAULT_BASE = 'https://scout.volibits.com';
const POLL_ALARM = 'scout-naukri-poll';
const ADV_SEARCH_URL =
  'https://resdex.naukri.com/cloudgateway-resdex/' +
  'recruiter-js-profile-listing-services/v0/search/results/advSearch';

async function getState() {
  return await chrome.storage.local.get(['scoutToken', 'scoutBase', 'polling', 'logs']);
}
async function setState(patch) {
  const cur = await chrome.storage.local.get(null);
  await chrome.storage.local.set({ ...cur, ...patch });
}
// Serialize log writes through a promise chain. Without this, two back-to-back
// (un-awaited) log() calls both read the same buffer and the second write clobbers
// the first — silently dropping lines (e.g. "LI hit keys:" right before "LI profile keys:").
let _logChain = Promise.resolve();
function log(line) {
  _logChain = _logChain.then(async () => {
    const ts = new Date().toLocaleTimeString();
    const cur = await chrome.storage.local.get('logs');
    const logs = (cur.logs || []).slice(-300);
    logs.push(`${ts}  ${line}`);
    await chrome.storage.local.set({ logs });
    console.log('[scout-agent]', line);
  }).catch(() => {});
  return _logChain;
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'scout-auth' && msg.token) {
    setState({ scoutToken: msg.token, scoutBase: msg.base || DEFAULT_BASE, scoutEmail: msg.email || '' });
    log('Scout login captured' + (msg.email ? ' (' + msg.email + ')' : ''));
  }
});

async function findResdexTab() {
  const tabs = await chrome.tabs.query({ url: 'https://resdex.naukri.com/*' });
  return tabs && tabs.length ? tabs[0] : null;
}

function waitForTabComplete(tabId, timeoutMs = 30000) {
  return new Promise(async (resolve) => {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      try {
        const t = await chrome.tabs.get(tabId);
        if (t.status === 'complete') { resolve(t); return; }
      } catch (e) { resolve(null); return; }   // tab closed
      await new Promise(r => setTimeout(r, 500));
    }
    try { resolve(await chrome.tabs.get(tabId)); } catch (e) { resolve(null); }
  });
}

// Human-like random pause before/between operations so the traffic doesn't look like
// a tight automated loop. Every network step waits a random number of seconds.
function randDelay(minMs, maxMs) {
  const ms = Math.floor(minMs + Math.random() * Math.max(0, maxMs - minMs));
  return new Promise(r => setTimeout(r, ms));
}

// Return a loaded Resdex tab. If none is open, quietly open one in the BACKGROUND
// (no focus stolen) and wait for it to finish loading, so the recruiter doesn't
// have to keep a Resdex tab open themselves.
// Return a tab that is LOADED and on the given host (so executeScript won't fail
// with "Cannot access contents of the page" on an about:blank/new-tab). Reuses an
// existing matching tab, else opens one in the background and waits for it.
function _tabOnHost(url, hostFrag) {
  return typeof url === 'string' && url.indexOf('https://') === 0 && url.indexOf(hostFrag) !== -1;
}
async function ensureTabOnHost(queryPatterns, openUrl, hostFrag, settleMs) {
  for (const q of queryPatterns) {
    const tabs = await chrome.tabs.query({ url: q });
    for (const t of tabs) {
      if (_tabOnHost(t.url, hostFrag)) {
        const ready = (t.status === 'complete') ? t : (await waitForTabComplete(t.id)) || t;
        return ready;
      }
    }
  }
  await log(`No ${hostFrag} tab open - opening one in the background...`);
  let tab = await chrome.tabs.create({ url: openUrl, active: false });
  tab = await waitForTabComplete(tab.id);
  // Verify it actually landed on the host (navigation can lag past 'complete').
  for (let i = 0; i < 8; i++) {
    tab = await chrome.tabs.get(tab.id).catch(() => null);
    if (tab && _tabOnHost(tab.url, hostFrag) && tab.status === 'complete') break;
    await new Promise(r => setTimeout(r, 1500));
  }
  if (!tab || !_tabOnHost(tab.url, hostFrag)) {
    await log(`could not load a ${hostFrag} tab (got ${tab ? tab.url : 'none'})`);
    return null;
  }
  await log(`using tab: ${tab.url}`);
  if (settleMs) await new Promise(r => setTimeout(r, settleMs));
  return tab;
}

async function ensureResdexTab() {
  return ensureTabOnHost(['https://resdex.naukri.com/*'],
    'https://resdex.naukri.com/v3?activeTab=advSrch', 'naukri.com', 2500);
}

// Read ALL naukri cookies (incl. httpOnly) for identity fields.
async function naukriCookies() {
  const map = {};
  try {
    const all = await chrome.cookies.getAll({ domain: 'naukri.com' });
    for (const c of all) map[c.name] = c.value;
  } catch (e) { /* ignore */ }
  return map;
}

function buildHeaders() {
  const txn = 'adv' + Date.now() + Math.random().toString(16).slice(2, 8) +
              '~~' + Math.random().toString(16).slice(2, 8);
  return {
    'Content-Type':     'application/json',
    'Accept':           'application/json',
    'appid':            '112',
    'systemid':         'naukriIndia',
    'x-transaction-id': txn,
  };
}

function identity(c) {
  // rdxUserId is the numeric recruiter id -> the UNCC cookie (NOT UNID, which is
  // a non-numeric token). Confirmed from the live advSearch payload.
  const rdxUserId = c.UNCC || c.resdexUserId || c.rdxUserId || c.userId || '';
  let companyId = c.UNPC || c.companyId || c.cid || '';
  for (const name in c) {
    const m = name.match(/^kycEligibleCookie(\d+)$/);
    if (m) { companyId = m[1]; break; }
  }
  const rdxUserName = c.lastLoggedInUser || c.userEmail || c.recruiterUserName || '';
  return { rdxUserId, companyId, rdxUserName };
}

const SKIP_LOCS = new Set(['india', 'in', 'bharat', 'remote', 'not specified', '']);

// Scout notice value -> Naukri notice "rank" (1=0-15d, 2=1mo, 3=2mo, 4=3mo, 5=>3mo).
// We select ALL codes <= the chosen threshold (e.g. "2 months" -> [1,2,3]), which
// matches both the captured payload and the "<= threshold" rule.
const NOTICE_RANK = { '15': 1, '30': 2, '60': 3, '90': 4, '100': 5 };
function noticeCodesFor(np) {
  if (!np) return [];
  if (String(np) === 'serving') return [1];   // currently serving ~ short notice
  const max = NOTICE_RANK[String(np)];
  if (!max) return [];
  const out = [];
  for (let c = 1; c <= max; c++) out.push(c);
  return out;
}

// Resolve city NAMES to Naukri's internal location IDs via the public taxonomy
// suggester (ACAO:* so the background can call it directly). Mirrors what the UI
// does when you type a city and pick it from the dropdown.
async function resolveLocationIds(locationStr) {
  const ids = [];
  const cities = (locationStr || '').split(/[/,|]/).map(s => s.trim()).filter(Boolean);
  for (const city of cities) {
    if (SKIP_LOCS.has(city.toLowerCase())) continue;
    try {
      const url = 'https://taxonomy-suggest.naukri.com/suggest/taxonomyCommonSuggester' +
        '?limit=15&appId=1&astext=' + encodeURIComponent(city) +
        '&resultField=id,name,type,parentTwoName&typoSupport=true&stringTypoMatch=true' +
        '&astype=city,state,country&category=location&c_query=null&p_query=null&sourceId=4001&vertical=';
      const r = await fetch(url, { credentials: 'include' });
      let t = await r.text();
      const m = t.match(/\(([\s\S]*)\)\s*;?\s*$/);   // strip JSONP wrapper if present
      if (m) t = m[1];
      const data = JSON.parse(t);
      // resultList is an object with a `title` array; each entry has name:[..], id:[..], type
      const arr = (data.resultList && Array.isArray(data.resultList.title)) ? data.resultList.title
                : Array.isArray(data.resultList) ? data.resultList
                : Array.isArray(data.results) ? data.results : [];
      const pick = v => Array.isArray(v) ? v[0] : v;
      const best = arr.find(x => (x.type || '').toLowerCase() === 'city') || arr[0];
      const idVal = best && pick(best.id);
      if (idVal != null && idVal !== '') {
        ids.push(String(idVal));
        await log(`location "${city}" -> ${idVal} (${pick(best.name) || ''})`);
      } else {
        await log(`location "${city}": no ID match`);
      }
    } catch (e) {
      await log(`location lookup failed for "${city}": ${e.message}`);
    }
  }
  return ids;
}

// Hard per-search cap for Naukri: one search never pulls more than this many profiles
// (one modest Resdex "page"), to keep volume/footprint low and less scraper-like.
const NAUKRI_PAGE_CAP = 40;
// Naukri sourcing is DISABLED (not removed). The server no longer queues 'naukri' jobs;
// this guard is belt-and-suspenders so the extension skips one even if it ever receives it.
// Flip to true to re-enable Naukri Resdex searches.
const NAUKRI_ENABLED = false;

function buildPayload(job, cookies, locIds) {
  const p = job.params || {};
  // locIds are Naukri's internal location IDs (e.g. ["220"]), resolved from city
  // names via the taxonomy suggester. Empty => India-wide. Full advSearchParams
  // mirrors a real Resdex request so the backend doesn't 500 on missing siblings.
  const locs = locIds || [];
  const adv = {
    activeIn:                 63,
    allOrNewCV:               'ALL',
    boolKeywords:             '',
    booleanSearch:            false,
    category:                 [],
    companyType:              { search_in: ['C'] },
    currency:                 'rs',
    currentLocations:         locs,
    designation:              [],
    designationState:         'C',
    designationStrType:       'ezkw',
    disabilityTypes:          [],
    employeesExclude:         [],
    employeesExcludeState:    'C',
    employeesExcludeStrType:  'ezkw',
    employeesInclude:         [],
    employeesIncludeState:    'C',
    employeesIncludeStrType:  'ezkw',
    exDefensePersonnelTypes:  [],
    excludeIndustryIds:       [],
    ezKeywordsAll:            [{ key: '-1', value: job.query || '', type: '' }],
    ezKeywordsAny:            [],
    ezKeywordsExclude:        [],
    fareaRoleIdsEntity:       [],
    filterPreferredCompanies: false,
    gender:                   'n',
    hiringForClient:          null,
    industryIds:              [],
    jobStatusType:            '',
    jobType:                  '',
    minCtcLacs:               0,
    minCtcThsnds:             0,
    minExp:                   parseInt(p.exp_min || 0, 10) || 0,
    noticePeriod:             [],
    otherLocations:           '',
    pgCourseSpecIds:          [],
    pgEducationType:          [0],
    pgInstitutes:             [],
    pgPpgCombinationCriteria: true,
    ppgCourseSpecIds:         [],
    ppgEducationType:         [0],
    ppgInstitutes:            [],
    prefLocationChecked:      locs.length > 0,
    prefLocationCriteria:     false,
    prefLocationDd:           1,
    prefLocationExactMatch:   false,
    prefLocations:            locs,
    resPerPage:               Math.min(job.limit || 20, NAUKRI_PAGE_CAP),
    searchAssistTabRequest:   false,
    searchOnZeroCtc:          true,
    selectedPgTab:            -1,
    selectedPpgTab:           -1,
    selectedUgTab:            -1,
    sortType:                 'RELEVANCE',
    srchKeywordsIn:           'ER',
    srchOnlyCvUploaded:       false,
    srchOnlyEmailVerified:    false,
    srchOnlyMobileVerified:   false,
    srchOnlyPhysicallyDisabled: false,
    srchType:                 'adv',
    stateLocations:           [],
    statePrefLocations:       [],
    swrExcludeKeywords:       [],
    swrIncludeKeywords:       [],
    swrKeywords:              '',
    topPgInstituteTags:       [],
    topPpgInstituteTags:      [],
    topUgInstituteTags:       [],
    ugCourseSpecIds:          [],
    ugEducationType:          [0],
    ugInstitutes:             [],
    ugPgCombinationCriteria:  true,
    ugPpgCombinationCriteria: false,
    womenReturningToWork:     null,
  };

  // Exclude company: keyword-based exclusion (no company-ID lookup needed).
  const _excl = (p.exclude_company || '').trim();
  if (_excl) adv.ezKeywordsExclude = [{ key: '-1', value: _excl, type: '' }];

  // Notice period: all Naukri codes <= the chosen threshold.
  adv.noticePeriod = noticeCodesFor(p.notice_period);

  const payload = { advSearchParams: adv };
  const id = identity(cookies);
  // Only include miscellaneousInfo when BOTH ids are clean integers — sending an
  // empty/non-numeric companyId or rdxUserId makes the Java backend reject the
  // body ("Illegal json format mapped"). If we can't resolve them, omit the block
  // and let the session identify the recruiter.
  const cidOk = /^\d+$/.test(String(id.companyId));
  const uidOk = /^\d+$/.test(String(id.rdxUserId));
  if (cidOk && uidOk) {
    payload.miscellaneousInfo = {
      companyId:         parseInt(id.companyId, 10),
      rdxUserId:         String(id.rdxUserId),
      rdxUserName:       id.rdxUserName,
      flowName:          'search',
      fetchClusters:     false,
      fetchResumeTuples: true,
    };
  }
  return payload;
}

const SEEKING_NOTICE = ['immediate', 'serving notice', '< 15 days', 'less than 15 days', '15 days or less'];
const SEEKING_STATUS = ['not employed', 'fresher', 'actively seeking', 'actively looking',
                        'actively applying', 'open to offers', 'open to work', 'immediate joiner'];

// Naukri Resdex shows current CTC as "₹ 32 Lacs" / "₹ 22.70 Lacs". The API field
// name is inconsistent across plans, so: 1) try common display fields, 2) build it
// from lac/thousand pairs wherever they live, 3) deep-scan for a salary-looking string.
const _SAL_RE = /(?:₹|rs\.?|inr)\s*[\d][\d.,]*\s*(?:lac|lakh|lpa|cr|crore)/i;
function extractNaukriSalary(c, eo) {
  // 0) Known advSearch structure: ctcInfo: { lacs:"32", thousands:"0", currency:"INR" }.
  const ci = c.ctcInfo || c.ctc || {};
  if (ci && typeof ci === 'object' && (ci.lacs != null || ci.thousands != null || ci.lac != null || ci.thousand != null)) {
    const li = parseInt(ci.lacs != null ? ci.lacs : (ci.lac || 0), 10);
    const ti = parseInt(ci.thousands != null ? ci.thousands : (ci.thousand || 0), 10);
    if (li || ti) return `${li}${ti ? '.' + String(ti).padStart(2, '0') : ''} Lacs`;
  }
  // 1) Direct preformatted display fields.
  for (const k of ['ctcDisplay', 'ctcText', 'salaryDisplay', 'currentCtcDisplay',
                   'ctcDetail', 'currentCtc', 'ctc', 'salary']) {
    const v = c[k];
    if (typeof v === 'string' && /\d/.test(v) && /lac|lakh|lpa|cr|₹/i.test(v)) return v.trim();
  }
  // 2) lac/thousand numeric pairs in any of the likely containers.
  const cur = (c.employment && c.employment.current) || {};
  for (const o of [c, eo || {}, cur, c.ctc || {}, c.compensation || {}]) {
    if (o && typeof o === 'object') {
      const l = o.ctcLac != null ? o.ctcLac : (o.ctcLacs != null ? o.ctcLacs : o.lac);
      const t = o.ctcThousand != null ? o.ctcThousand : (o.ctcThousands != null ? o.ctcThousands : o.thousand);
      if (l != null || t != null) {
        const li = parseInt(l || 0, 10), ti = parseInt(t || 0, 10);
        if (li || ti) return `${li}${ti ? '.' + String(ti).padStart(2, '0') : ''} Lacs`;
      }
    }
  }
  // 3) Deep KEY-based scan (depth<=3). The advSearch API returns CTC as numbers under
  //    a field whose name contains "ctc"/"salary" — match by key name, not value shape.
  let found = '';
  const seen = new Set();
  const fmtLac = (lac, thou) => `${parseInt(lac || 0, 10)}${thou ? '.' + String(parseInt(thou, 10)).padStart(2, '0') : ''} Lacs`;
  const numToSalary = (v) => v >= 100000 ? `${Math.round(v / 10000) / 10} LPA` : `${v} LPA`; // rupees vs lakhs
  (function walk(o, depth) {
    if (found || o == null || depth > 3 || typeof o !== 'object' || seen.has(o)) return;
    seen.add(o);
    // lac/thousand pair at this level (any naming).
    const lac = o.ctcLac != null ? o.ctcLac : (o.ctcLacs != null ? o.ctcLacs : (o.lac != null ? o.lac : o.lacs));
    const thou = o.ctcThousand != null ? o.ctcThousand : (o.ctcThousands != null ? o.ctcThousands : (o.thousand != null ? o.thousand : o.thousands));
    if ((lac != null && lac !== '') || (thou != null && thou !== '')) {
      const li = parseInt(lac || 0, 10), ti = parseInt(thou || 0, 10);
      if (li || ti) { found = fmtLac(li, ti); return; }
    }
    for (const k of Object.keys(o)) {
      if (found) break;
      const v = o[k];
      if (/ctc|salary/i.test(k)) {
        if (typeof v === 'string' && /\d/.test(v)) { found = v.trim(); break; }
        if (typeof v === 'number' && v > 0) { found = numToSalary(v); break; }
        if (v && typeof v === 'object') { walk(v, depth + 1); if (found) break; }
      }
      if (v && typeof v === 'object') walk(v, depth + 1);
    }
  })(c, 0);
  return found;
}

function mapTuple(c, fallbackTitle) {
  const name = c.jsUserName || c.name || c.fullName || 'Unknown';
  const empCur = (c.employment && c.employment.current) || {};
  const role = empCur.designation || c.jobTitle || c.designation || fallbackTitle || '';
  const company = empCur.organization || c.currentEmployer || c.company || '';
  let exp = '', expYears = null;
  const eo = c.experience || {};
  if (eo && typeof eo === 'object' && eo.years != null) {
    const y = parseInt(eo.years, 10), mo = parseInt(eo.months || 0, 10);
    exp = mo ? `${y}y ${mo}m` : `${y}y`;
    expYears = Math.round((y + mo / 12) * 10) / 10;
  }
  const skillsRaw = c.keySkills || c.focusedSkills || '';
  const skills = Array.isArray(skillsRaw) ? skillsRaw.slice(0, 8)
    : (skillsRaw ? skillsRaw.split(',').map(s => s.trim()).filter(Boolean).slice(0, 8) : []);
  const npLabel = c.noticePeriodLabel || '';
  const npRaw = c.noticePeriod || '';
  const notice = String(npLabel).trim() || (/^\d+$/.test(String(npRaw)) ? '' : String(npRaw).trim());
  const tags = c.profileTags || [];
  let activity = '';
  for (const t of tags) { if (t && t.label) { activity = t.label; break; } }
  const immediate = !!(c.immediateAvailabilty || c.immediateAvailability);
  const nl = notice.toLowerCase(), al = activity.toLowerCase();
  const otw = immediate || SEEKING_NOTICE.some(v => nl.includes(v)) || SEEKING_STATUS.some(v => al.includes(v));
  const uid = c.uniqueId || c.profileId || c.id || '';
  // Contact info — present in the Resdex listing when the recruiter's plan exposes it.
  const email = c.email || c.emailId || c.emailAddress || c.email_id || '';
  const phoneRaw = c.phoneNumber || c.mobile || c.phone || c.mobileNumber || c.contactNumber || '';
  const phone = phoneRaw ? String(phoneRaw).trim() : '';
  // Current salary / CTC. Naukri's listing shows it as e.g. "₹ 32 Lacs" / "₹ 22.70 Lacs"
  // but the API field name varies, so extract robustly instead of guessing one key.
  const salary = extractNaukriSalary(c, eo);
  // Expected salary: expectedCtcLacs/expectedCtcThousands (strings like "35.0").
  let expectedSalary = '';
  {
    const l = parseInt(parseFloat(c.expectedCtcLacs || 0), 10);
    const t = parseInt(parseFloat(c.expectedCtcThousands || 0), 10);
    if (l || t) expectedSalary = `${l}${t ? '.' + String(t).padStart(2, '0') : ''} Lacs`;
  }
  // Preferred work locations (comma-separated string).
  const prefLocations = (typeof c.preferredLocations === 'string' && c.preferredLocations) ? c.preferredLocations.trim() : '';
  // "Active today" / "Active 3 days ago" etc.
  const activeLabel = (c.activeDateLabel || activity || '').trim();
  const emp = c.employment || {};
  const edu = c.education || {};
  return {
    name, role, company, email: String(email).trim(), phone, salary,
    expected_salary: expectedSalary,
    location: (typeof c.currentLocation === 'string' && c.currentLocation) || '',
    pref_locations: prefLocations,
    linkedin: '', naukri: uid ? `https://resdex.naukri.com/recruiter-profile/${uid}` : '',
    skills, experience: exp, exp_years: expYears, notice, notice_period: notice,
    activity, active_label: activeLabel,
    cv_available: !!(c.cvAttached || c.cvPreviewRedirectionUrl),
    headline: (c.resumeHeadline || c.profileTitle || c.summary || '').trim(),
    tags: [], source: 'naukri-resdex', open_to_work: otw,
    // ── Full detail set (for the candidates DB table) ──────────────────────
    details: {
      unique_id: uid,
      js_user_id: c.jsUserId || null,
      js_res_id: c.jsResId || null,
      photo_id_hash: c.photoIdHash || c.thumbnailPhotoIdHash || '',
      photo_url: '',                                  // built once we know Naukri's CDN format
      skills_all: skillsRaw && typeof skillsRaw === 'string' ? skillsRaw : (Array.isArray(skillsRaw) ? skillsRaw.join(', ') : ''),
      focused_skills: c.focusedSkills || '',
      current_designation: (emp.current || {}).designation || '',
      current_company: (emp.current || {}).organization || '',
      current_start: (emp.current || {}).startDate || '',
      previous_designation: (emp.previous || {}).designation || '',
      previous_company: (emp.previous || {}).organization || '',
      employment_history: c.historicalEmployment || [],
      education_ug: edu.ug || null,
      education_pg: edu.pg || null,
      education_ppg: edu.ppg || null,
      ctc_current: salary,
      ctc_expected: expectedSalary,
      ctc_fixed_lacs: c.fixedCtcLacs || null,
      ctc_variable_lacs: c.variableCtcLacs || null,
      salary_disclosed: !!c.salaryDisclosed,
      preferred_locations: prefLocations,
      notice_period_label: c.noticePeriodLabel || '',
      notice_period_code: c.noticePeriod != null ? c.noticePeriod : null,
      certifications: c.certifications || null,
      email_verified: !!c.emailVerified,
      mobile_verified: !!c.mobileNumberPresent,
      cv_attached: !!c.cvAttached,
      num_views: c.numberOfViews || 0,
      num_downloads: c.numberOfDownloads || 0,
      active_date_millis: c.activeDateMillis || null,
      modify_date_millis: c.modifyDateMillis || null,
      fresher: !!c.fresher,
      premium: !!(c.premiumCandidate || c.premiumTalent),
    },
    raw: c,                                            // full tuple — nothing lost
  };
}

// Runs in the PAGE's MAIN world (same-origin) so custom headers + cookies work.
function pageFetch(url, headers, body) {
  return fetch(url, { method: 'POST', credentials: 'include', headers, body: JSON.stringify(body) })
    .then(r => r.text().then(t => ({ status: r.status, ok: r.ok, text: t })))
    .catch(e => ({ status: 0, ok: false, text: String(e) }));
}

async function callResdex(tabId, payload) {
  const [res] = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func: pageFetch,
    args: [ADV_SEARCH_URL, buildHeaders(), payload],
  });
  return res && res.result;
}

async function postResults(callbackUrl, callbackToken, searchId, candidates, error, projectUrl, source, projectName, addBlocked) {
  const body = { search_id: searchId, candidates: candidates || [], error: error || null };
  if (projectUrl) body.project_url = projectUrl;
  if (source) body.source = source;
  if (projectName) body.project_name = projectName;
  if (addBlocked) body.add_blocked = true;
  const res = await fetch(callbackUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + callbackToken },
    body: JSON.stringify(body),
  });
  return res.status;
}

async function runJob(tab, job, cookies) {
  const _id = identity(cookies);
  await log(`identity: rdxUserId=${_id.rdxUserId || '(none)'} companyId=${_id.companyId || '(none)'}`);
  const locIds = await resolveLocationIds((job.params || {}).location);
  const payload = buildPayload(job, cookies, locIds);
  await randDelay(2000, 5000);                       // human-like pause before searching
  const r = await callResdex(tab.id, payload);
  if (!r) return { ok: false, error: 'no response from page fetch' };
  if (r.status === 401 || r.status === 403) return { ok: false, error: `Resdex ${r.status}: ${(r.text || '').slice(0, 250)}` };
  if (!r.ok) return { ok: false, error: `Resdex API HTTP ${r.status}: ${(r.text || '').slice(0, 200)}` };
  let data;
  try { data = JSON.parse(r.text); } catch (e) { return { ok: false, error: 'bad JSON from Resdex' }; }
  const raw = data.tuples || data.profileList || data.candidates || data.results || [];
  // One-time diagnostic: log the first profile's structure so we can pin the real
  // CTC / profile-id field names. Dump ALL top-level key names, plus the values of
  // any key that looks money- or id-related.
  if (raw[0]) {
    const c0 = raw[0];
    await log(`naukri ALL keys: ${Object.keys(c0).join(',').slice(0, 700)}`);
    const interesting = Object.keys(c0).filter(k => /id|url|link|profile|resume|username|encrypt|ctc|salary|sal|lac|comp|pay|employ/i.test(k));
    const dump = interesting.map(k => `${k}=${JSON.stringify(c0[k]).slice(0, 80)}`).join(' | ');
    await log(`naukri profile fields: ${dump.slice(0, 800)}`);
  }
  const cap = Math.min(job.limit || 20, NAUKRI_PAGE_CAP);
  if ((job.limit || 0) > NAUKRI_PAGE_CAP) {
    await log(`naukri: per-search cap ${NAUKRI_PAGE_CAP} applied (requested ${job.limit})`);
  }
  const candidates = raw.slice(0, cap).map(c => mapTuple(c, job.query));
  return { ok: true, candidates, total: data.totalResumes };
}

// ── LinkedIn Recruiter (talentRecruiterSearchHits) ──────────────────────────
const LI_SEARCH_URL = 'https://www.linkedin.com/talent/search/api/talentRecruiterSearchHits';
// Hard per-search ceiling for LinkedIn (incl. create-project pagination) — keeps
// volume/footprint modest and less scraper-like.
const LI_MAX_RESULTS = 100;

// Field projection (subset of the real decoration). LinkedIn expects ( ) , as
// %28 %29 %2C ; ~ and * stay literal.
const LI_DECORATION_RAW =
  '(entityUrn,linkedInMemberProfileUrn~(entityUrn,firstName,lastName,unobfuscatedFirstName,' +
  'unobfuscatedLastName,headline,industryName,location(displayName),publicProfileUrl,networkDistance,' +
  'memberPreferences(openToNewOpportunities),currentPositions*(companyName,title,startDateOn,location(displayName))))';
// Richer projection — pulls the full work history (for tenure-summed experience-years),
// the full member preferences (notice/locations/titles/employment), the profile photo
// vector and education. All of these resolve on the member-profile entity (the `~`
// resolution + `*` array markers stay literal; only ( ) , are %-encoded). If LinkedIn
// rejects this projection, liSearchPage transparently retries with LI_DECORATION_RAW.
const LI_DECORATION_RICH =
  '(entityUrn,linkedInMemberProfileUrn~(entityUrn,referenceUrn,firstName,lastName,unobfuscatedFirstName,' +
  'unobfuscatedLastName,headline,industryName,summary,numConnections,location(displayName),publicProfileUrl,' +
  'networkDistance,vectorProfilePicture(rootUrl,artifacts*(width,height,fileIdentifyingUrlPathSegment)),' +
  'memberPreferences(openToNewOpportunities,openToWorkRemotely,jobSeekingUrgencyLevel,locations,titles,' +
  'employmentTypes,interestedCandidateIntroductionStatement),' +
  'currentPositions*(companyName,title,startDateOn,location(displayName)),' +
  'groupedWorkExperience*(startDateOn(month,year),endDateOn(month,year),companyUrn~(name),' +
  'positions*(title,companyName,startDateOn(month,year),endDateOn(month,year))),' +
  'educations*(schoolName,degreeName,fieldOfStudy,startDateOn(year))))';
function liEncDecoration(s) { return s.replace(/\(/g, '%28').replace(/\)/g, '%29').replace(/,/g, '%2C'); }

// Encode a RestLi text VALUE (space->%20, comma->%2C, parens, colon, etc.)
function liEncVal(s) {
  return encodeURIComponent(String(s)).replace(/[()'!*~]/g, c => '%' + c.charCodeAt(0).toString(16).toUpperCase());
}

// Strip RestLi-structural characters from a query VALUE. LinkedIn's recruiterSearch
// parser 422s when titles/skills/criteria contain ( ) , : (e.g. AI output like
// "Tosca framework (TDS, TDM)" or "SAP expertise: GUI, Fiori"), even URL-encoded.
function liClean(s) {
  return String(s == null ? '' : s).replace(/[(),:]+/g, ' ').replace(/\s+/g, ' ').trim();
}

// LinkedIn "Years of experience" range filter (the From–To slider). It's the real
// TOTAL_YEARS_OF_EXPERIENCE_RANGE facet, encoded as two endpoint values: From (min,
// selected:true) + To (max). Years clamp to 0..30 (the slider's range).
function liExpFacetSelection(min, max) {
  let lo = Math.max(0, Math.min(30, parseInt(min, 10) || 0));
  let hi = Math.max(0, Math.min(30, parseInt(max, 10) || 0));
  if (hi < lo) hi = lo;
  const vals = [
    `(value:${lo},displayValue:${lo},selected:true,negated:false,required:false)`,
    `(value:${hi},displayValue:${hi},negated:false,required:false)`,
  ];
  return `(type:TOTAL_YEARS_OF_EXPERIENCE_RANGE,valuesWithSelections:List(${vals.join(',')}))`;
}

// LinkedIn notice-period segment values (attr 224001), ascending by days.
const LI_NOTICE = [
  { days: 0,    id: '1620001', label: 'Immediately available' },
  { days: 15,   id: '248001',  label: '15 days or less' },
  { days: 30,   id: '249001',  label: '30 days' },
  { days: 45,   id: '1619001', label: '45 days' },
  { days: 60,   id: '250001',  label: '60 days' },
  { days: 90,   id: '250002',  label: '90 days' },
  { days: 9999, id: '249002',  label: 'More than 90 days' },
];
// LinkedIn expected-salary segment values (attr 1505001), ascending by lakhs.
const LI_SALARY = [
  { lakhs: 1,   id: '1616001', label: '₹ 1+ Lakhs' },
  { lakhs: 3,   id: '1617001', label: '₹ 3+ Lakhs' },
  { lakhs: 6,   id: '1618001', label: '₹ 6+ Lakhs' },
  { lakhs: 10,  id: '1618002', label: '₹ 10+ Lakhs' },
  { lakhs: 15,  id: '251001',  label: '₹ 15+ Lakhs' },
  { lakhs: 25,  id: '251002',  label: '₹ 25+ Lakhs' },
  { lakhs: 40,  id: '252001',  label: '₹ 40+ Lakhs' },
  { lakhs: 60,  id: '252002',  label: '₹ 60+ Lakhs' },
  { lakhs: 75,  id: '253001',  label: '₹ 75+ Lakhs' },
  { lakhs: 100, id: '251003',  label: '₹ 1+ Cr' },
];
function liNoticeValues(np) {
  if (!np) return [];
  let t;
  if (String(np) === '100') t = 9999;        // "more than 3 months" -> all
  else if (String(np) === 'serving') t = 15; // serving notice ~ short
  else t = parseInt(np, 10) || 0;
  return LI_NOTICE.filter(n => n.days <= t);
}
function liSalaryValues(maxBudget) {
  const b = parseFloat(maxBudget);
  if (!b) return [];
  return LI_SALARY.filter(s => s.lakhs <= b);
}
function liSegAttr(attrId, vals) {
  const vlist = vals.map(v =>
    `(displayValue:${liEncVal(v.label)},negated:false,` +
    `attributeValueV2Urn:${liEncVal('urn:li:ts_segment_attribute_value_v2:' + v.id)},` +
    `selected:true,required:false)`).join(',');
  return `(attributeV2Urn:${liEncVal('urn:li:ts_segment_attribute_v2:' + attrId)},` +
         `attributeValues:List(${vlist}))`;
}

function buildLiBody(job, geos, company, opts) {
  const p = job.params || {};
  const title = job.query || p.title || '';
  const skills = (p.skills || []).slice(0, 8);
  const expMin = parseInt(p.exp_min || 0, 10) || 0;
  const expMax = parseInt(p.exp_max || 0, 10) || 0;
  const isCreateProject = job.source === 'create_project';
  // OTW (TALENT_POOL isInterestedCandidate:true) spotlight filter. Controlled by the
  // Delivery-Head "Open to Work" toggle (passed as open_to_work). Default ON; when the
  // user unticks it (open_to_work:false) we extract everyone.
  const otw = p.open_to_work !== false;
  const parts = ['capSearchSortBy:RELEVANCE'];
  // Titles vs keywords:
  //  • Regular recruiter search → structured titles:List (job-title match).
  //  • create-project → leave the job-TITLE filter BLANK and drive the search by
  //    keywords (skills) instead. The title filter was matching incorrectly/too
  //    narrowly, so for project creation we search purely on keywords + skills.
  if (!isCreateProject) {
    const titlesArr = (Array.isArray(p.titles) && p.titles.length) ? p.titles.slice(0, 5) : [title];
    const titleItems = titlesArr.map(t => liClean(t)).filter(Boolean)
      .map(t => `(text:${liEncVal(t)},negated:false,required:false)`);
    if (titleItems.length) parts.push(`titles:List(${titleItems.join(',')})`);
  }
  // Free-text keywords — broadens recall, and is the primary matcher for create-project
  // (where the title filter is intentionally blank). Built from the primary skills, OR-ed
  // so a candidate matching ANY of them is in the pool (skills:List below still ranks).
  const kwTerms = skills.map(s => liClean(s)).filter(Boolean);
  if (kwTerms.length) parts.push(`keywords:${liEncVal(kwTerms.join(' OR '))}`);
  // Qualifications (semanticCriteriaDetails) = JD-derived criteria phrases only.
  // Experience is applied as the real Years-of-experience range FACET below (the From–To
  // slider), not a soft qualification — so it actually filters instead of just ranking.
  const sem = [];
  for (const c of (p.criteria || []).slice(0, 8)) {
    const cc = liClean(c);
    if (cc) sem.push(`(qualifier:PREFERRED,text:${liEncVal(cc)})`);
  }
  if (sem.length) parts.push(`semanticCriteriaDetails:List(${sem.join(',')})`);
  // Skills -> structured skills:List. LinkedIn's required:true means a candidate must
  // have ALL of them (narrow, can collapse to zero). Default = PREFERRED (broad, ranks
  // by match). When the user toggles "require must-have skills" on, gate with required:true.
  // create_project always stays preferred (it needs a broad pool to pick the top N from).
  const requireSkills = p.require_skills === true && job.source !== 'create_project';
  const mustHave = skills;                          // p.skills (primary / must-have)
  const canHave  = (p.pref_skills || []).slice(0, 8); // good-to-have
  const skillItems = [];
  for (const s0 of mustHave) { const s = liClean(s0); if (s) skillItems.push(`(text:${liEncVal(s)},negated:false,required:${requireSkills ? 'true' : 'false'},displayValue:${liEncVal(s)})`); }
  for (const s0 of canHave)  { const s = liClean(s0); if (s) skillItems.push(`(text:${liEncVal(s)},negated:false,required:false,displayValue:${liEncVal(s)})`); }
  if (skillItems.length) {
    parts.push(`skills:List(${skillItems.join(',')})`);
    parts.push('skillScope:ALL_PROFILE_SKILLS');
  }
  // Exclude company: top-level companies:List (negated) + companyScope (not a facet).
  if (company && company.id) {
    parts.push(`companies:List((text:${liEncVal(liClean(company.name || ''))},` +
      `entity:${liEncVal('urn:li:ts_company:' + company.id)},negated:true,required:false,` +
      `selected:true,scope:(timeScope:CURRENT_OR_PAST)))`);
    parts.push('companyScope:CURRENT_OR_PAST');
  }
  const facets = [], facetSel = [];
  // Geo facet (BING_GEO_SWR): include the target location(s) (negated:false — candidates in
  // ANY of them match) and EXCLUDE any JD-excluded cities (negated:true) in the SAME facet —
  // exactly how Recruiter's UI encodes multi-city + "except Mumbai" (from a network capture).
  const includeGeos = Array.isArray(geos) ? geos : (geos ? [geos] : []);
  const excludeGeos = (opts && opts.excludeGeos) || [];
  if (includeGeos.length || excludeGeos.length) {
    const geoVals = [];
    for (const ig of includeGeos) {
      if (ig && ig.id) geoVals.push(`(value:${liEncVal(ig.id)},displayValue:${liEncVal(ig.displayName || '')},negated:false,required:false)`);
    }
    for (const eg of excludeGeos) {
      if (eg && eg.id) geoVals.push(`(value:${liEncVal(eg.id)},displayValue:${liEncVal(eg.displayName || '')},` +
        `negated:true,selected:true,required:false,scope:(geoRegionScope:CURRENT))`);
    }
    if (geoVals.length) {
      facets.push('BING_GEO_SWR');
      facetSel.push(`(type:BING_GEO_SWR,valuesWithSelections:List(${geoVals.join(',')}))`);
    }
  }
  if (otw) {
    facets.push('TALENT_POOL');
    facetSel.push('(type:TALENT_POOL,valuesWithSelections:List((value:' +
      liEncVal('isInterestedCandidate:true') + ',negated:false,required:false)))');
  }
  // Years-of-experience range (the From–To slider). Applied whenever a min or max is set;
  // an absent bound opens to that end (min 0 / max 30+).
  if (expMin > 0 || expMax > 0) {
    facets.push('TOTAL_YEARS_OF_EXPERIENCE_RANGE');
    facetSel.push(liExpFacetSelection(expMin > 0 ? expMin : 0, expMax > 0 ? expMax : 30));
  }
  // Notice period + expected salary (max budget) via segment attributes.
  const segAttrs = [];
  const npVals = liNoticeValues(p.notice_period);
  if (npVals.length) segAttrs.push(liSegAttr('224001', npVals));
  const salVals = liSalaryValues(p.salary_max);
  if (salVals.length) segAttrs.push(liSegAttr('1505001', salVals));
  if (segAttrs.length) {
    facets.push('SEGMENT_ATTRIBUTE_AND_VALUES');
    parts.push(`segmentAttributes:List(${segAttrs.join(',')})`);
  }
  if (facets.length) {
    parts.push(`facets:List(${facets.join(',')})`);
    parts.push(`facetSelections:List(${facetSel.join(',')})`);
  }
  const query = `(${parts.join(',')})`;
  const requestParams = '(doFacetCounting:true,doFacetDecoration:true,uiOrigin:GLOBAL_SEARCH_HEADER)';
  // opts.{start,count} let create-project paginate (LinkedIn returns ~25/page).
  const count = (opts && opts.count) || Math.min(job.limit || 25, 50);
  const start = (opts && opts.start) || 0;
  // Rich projection by default; liSearchPage falls back to the minimal one on rejection.
  const decoRaw = (opts && opts.minimalDecoration) ? LI_DECORATION_RAW : LI_DECORATION_RICH;
  return `decoration=${liEncDecoration(decoRaw)}&count=${count}&q=recruiterSearch` +
         `&query=${query}&requestParams=${requestParams}&start=${start}`;
}

// MAIN-world fetch for LinkedIn (POST + x-http-method-override:GET, form body).
function liPageFetch(url, headers, body) {
  return fetch(url, { method: 'POST', credentials: 'include', headers, body })
    .then(r => r.text().then(t => ({ status: r.status, ok: r.ok, text: t })))
    .catch(e => ({ status: 0, ok: false, text: String(e) }));
}

async function liCsrfToken() {
  try {
    const c = await chrome.cookies.get({ url: 'https://www.linkedin.com', name: 'JSESSIONID' });
    return c ? c.value.replace(/^"|"$/g, '') : '';   // strip surrounding quotes
  } catch (e) { return ''; }
}

// MAIN-world GET (same-origin) for LinkedIn typeahead etc.
function liPageGet(url, headers) {
  return fetch(url, { method: 'GET', credentials: 'include', headers })
    .then(r => r.text().then(t => ({ status: r.status, ok: r.ok, text: t })))
    .catch(e => ({ status: 0, ok: false, text: String(e) }));
}

// Resolve a city NAME to LinkedIn's geo ID via the talentTypeaheads endpoint
// (run in MAIN world; same-origin so cookies + csrf header work).
async function resolveLiGeo(tabId, city, csrf) {
  if (!city) return null;
  const url = 'https://www.linkedin.com/talent/api/talentTypeaheads?q=geo&query=' +
              encodeURIComponent(city) + '&useCase=RECRUITER_SEARCH';
  const headers = { 'accept': 'application/json', 'csrf-token': csrf, 'x-restli-protocol-version': '2.0.0' };
  let res;
  try {
    [res] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: liPageGet, args: [url, headers] });
  } catch (e) { return null; }
  const r = res && res.result;
  if (!r || !r.ok) return null;
  let data; try { data = JSON.parse(r.text); } catch (e) { return null; }
  const els = data.elements || [];
  const geoOf = e => (e.hitInfoUnion && e.hitInfoUnion.typeaheadBingGeoLocation) || {};
  const cl = city.toLowerCase();
  // Prefer an India match that starts with the typed city, else any starts-with, else first.
  const pick = els.find(e => { const g = geoOf(e); return g.countryCode === 'IN' && (g.displayName || '').toLowerCase().startsWith(cl); })
            || els.find(e => { const g = geoOf(e); return (g.displayName || '').toLowerCase().startsWith(cl); })
            || els[0];
  if (!pick) return null;
  const g = geoOf(pick);
  const id = String(g.geoUrn || g.entityUrn || '').split(':').pop();
  return id ? { id, displayName: g.displayName || city } : null;
}

// Resolve a company NAME to its ts_company id via talentTypeaheads (MAIN world).
async function resolveLiCompany(tabId, name, csrf) {
  if (!name) return null;
  const url = 'https://www.linkedin.com/talent/api/talentTypeaheads?q=company&query=' + encodeURIComponent(name);
  const headers = { 'accept': 'application/json', 'csrf-token': csrf, 'x-restli-protocol-version': '2.0.0' };
  let res;
  try { [res] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: liPageGet, args: [url, headers] }); }
  catch (e) { return null; }
  const r = res && res.result;
  if (!r || !r.ok) return null;
  let data; try { data = JSON.parse(r.text); } catch (e) { return null; }
  const els = data.elements || [];
  const nl = name.toLowerCase();
  const txt = e => ((e.text && e.text.text) || '').toLowerCase();
  const pick = els.find(e => txt(e) === nl) || els.find(e => txt(e).includes(nl)) || els[0];
  if (!pick) return null;
  const co = (pick.hitInfoUnion && pick.hitInfoUnion.typeaheadCompany) || {};
  const id = String(co.company || co.entityUrn || '').split(':').pop();
  return id ? { id, name: (pick.text && pick.text.text) || name } : null;
}

// Total experience in years from groupedWorkExperience. Sums each company's tenure but
// UNIONs overlapping/nested intervals (a person can hold a "company" group and a "role"
// position inside it over the same span, and unrelated stints can overlap) so time is
// never double-counted. Returns a 1-decimal number, or null when no dated history.
function liExpFromGroups(groups) {
  if (!Array.isArray(groups) || !groups.length) return null;
  const now = new Date();
  const nowM = now.getFullYear() * 12 + now.getMonth();
  const ivs = [];
  const add = (sd, ed) => {
    if (!sd || !sd.year) return;
    const sM = sd.year * 12 + ((sd.month || 1) - 1);
    const eM = (ed && ed.year) ? ed.year * 12 + ((ed.month || 1) - 1) : nowM; // ongoing -> now
    if (eM >= sM) ivs.push([sM, eM]);
  };
  for (const g of groups) {
    const pos = Array.isArray(g.positions) ? g.positions : [];
    if (pos.length) pos.forEach(p => add(p.startDateOn, p.endDateOn));
    else add(g.startDateOn, g.endDateOn);            // group-level dates as fallback
  }
  if (!ivs.length) return null;
  ivs.sort((a, b) => a[0] - b[0]);
  let tot = 0, cs = ivs[0][0], ce = ivs[0][1];
  for (let i = 1; i < ivs.length; i++) {
    const [s, e] = ivs[i];
    if (s <= ce) { if (e > ce) ce = e; } else { tot += ce - cs; cs = s; ce = e; }
  }
  tot += ce - cs;
  return Math.round((tot / 12) * 10) / 10;
}

// Best photo URL from a vectorProfilePicture (rootUrl + a >=200px artifact path).
function liPhotoUrl(vpp) {
  if (!vpp || !vpp.rootUrl || !Array.isArray(vpp.artifacts) || !vpp.artifacts.length) return '';
  const arts = vpp.artifacts.slice().sort((a, b) => (a.width || 0) - (b.width || 0));
  const pick = arts.find(a => (a.width || 0) >= 200) || arts[arts.length - 1];
  const seg = pick.fileIdentifyingUrlPathSegment || '';
  if (/^https?:/i.test(seg)) return seg;             // some artifacts carry a full URL
  return vpp.rootUrl + seg;
}

// Latest/current company from groupedWorkExperience when currentPositions is empty —
// the group with the latest end (ongoing = latest).
function liLatestCompany(groups) {
  if (!Array.isArray(groups) || !groups.length) return { company: '', title: '' };
  let best = null, bestEnd = -1;
  for (const g of groups) {
    const ed = g.endDateOn;
    const e = (ed && ed.year) ? ed.year * 12 + ((ed.month || 1) - 1) : Infinity; // ongoing wins
    if (e > bestEnd) { bestEnd = e; best = g; }
  }
  if (!best) return { company: '', title: '' };
  const p0 = (best.positions || [])[0] || {};
  return {
    company: (best.companyUrnResolutionResult && best.companyUrnResolutionResult.name) || p0.companyName || '',
    title: p0.title || '',
  };
}

// Map LinkedIn's job-seeking urgency / intro statement to a notice-period label.
function liNoticeFromPrefs(mp) {
  const intro = String((mp && mp.interestedCandidateIntroductionStatement) || '');
  if (/join\s+immediately|immediate/i.test(intro)) return 'Immediately available';
  const u = String((mp && mp.jobSeekingUrgencyLevel) || '');
  if (/ACTIVELY_SEEKING/i.test(u)) return 'Actively seeking';
  if (/OPEN/i.test(u)) return 'Open to opportunities';
  return '';
}

let _liDiagLogged = false;
let _liPhotoDbgLogged = false;
function parseLiElements(data, limit) {
  const els = data.elements || data.results || [];
  // One-time diagnostic: dump the search-hit + resolved-profile field names so we can
  // see whether full positions / education / matched-qualifications are already in the
  // API response (vs needing a richer decoration or a separate request).
  if (!_liDiagLogged && els[0]) {
    _liDiagLogged = true;
    const e0 = els[0];
    const pr0 = e0.linkedInMemberProfileUrnResolutionResult || e0.linkedInMemberProfileUrn || {};
    log('LI hit keys: ' + Object.keys(e0).join(','));
    log('LI profile keys: ' + Object.keys(pr0).join(','));
    // Dump the value of any qualification/criteria/relevance field so we can map the
    // "High qualification relevance" found/missed popup.
    for (const k of Object.keys(e0)) {
      if (/qual|criteria|spotlight|insight|highlight|relevance|matchscore|reason/i.test(k)) {
        log('LI hit.' + k + ': ' + JSON.stringify(e0[k]).slice(0, 600));
      }
    }
  }
  const out = [];
  for (const e of els.slice(0, limit || 25)) {
    const pr = e.linkedInMemberProfileUrnResolutionResult || e.linkedInMemberProfileUrn || {};
    const name = ((pr.unobfuscatedFirstName || pr.firstName || '') + ' ' +
                  (pr.unobfuscatedLastName || pr.lastName || '')).trim() || 'LinkedIn member';
    const cp = (pr.currentPositions || [])[0] || {};
    const mp = pr.memberPreferences || {};
    // Build the in-Recruiter profile link from the ts_profile id (open inside
    // LinkedIn Recruiter, not the public /in/ page).
    let tsId = '';
    const ref = pr.referenceUrn || '';
    if (ref.indexOf('urn:li:ts_profile:') === 0) tsId = ref.split(':').pop();
    if (!tsId && pr.entityUrn) {
      const m = pr.entityUrn.match(/ts_profile:([A-Za-z0-9_-]+)/);
      if (m) tsId = m[1];
    }
    const recruiterUrl = tsId
      ? `https://www.linkedin.com/talent/profile/${tsId}`
      : (pr.publicProfileUrl || '');
    // Contact info — only present if LinkedIn returns it (usually requires unlock).
    const ci = pr.contactInfo || pr.contactInformation || {};
    const liEmail = pr.emailAddress || ci.emailAddress ||
      ((ci.emailAddresses || [])[0] && ((ci.emailAddresses[0].emailAddress) || ci.emailAddresses[0])) || '';
    const liPhone = pr.phoneNumber ||
      ((ci.phoneNumbers || [])[0] && ((ci.phoneNumbers[0].number) || (ci.phoneNumbers[0].phoneNumber) || ci.phoneNumbers[0])) || '';
    // Expected salary if the profile exposes a compensation preference.
    const liSalary = (mp.salary && (mp.salary.displayValue || mp.salary.amount)) ||
      pr.expectedSalary || pr.compensation || '';
    const positions = pr.currentPositions || [];
    // ── Experience (tenure-summed) + current company + photo + prefs, all from the
    // rich projection's structured data (no DOM scraping needed when present). ────────
    const groups = pr.groupedWorkExperience || [];
    const expYears = liExpFromGroups(groups);
    let curCompany = cp.companyName || '';
    let curTitle = cp.title || '';
    if (!curCompany) {
      const latest = liLatestCompany(groups);
      curCompany = latest.company || curCompany;
      if (!curTitle) curTitle = latest.title;
    }
    const photoUrl = liPhotoUrl(pr.vectorProfilePicture);
    const prefLocations = Array.isArray(mp.locations) ? mp.locations.filter(Boolean) : [];
    const noticeLabel = liNoticeFromPrefs(mp);
    // Capture any qualification/criteria-relevance info LinkedIn returns on the hit
    // (the "High qualification relevance" found/missed data). Field name varies, so grab
    // anything that looks like it — the diagnostic above reveals the exact key.
    const qualifications = {};
    for (const k of Object.keys(e)) {
      if (/qual|criteria|spotlight|relevance|matchscore/i.test(k) && e[k] != null) qualifications[k] = e[k];
    }
    out.push({
      name,
      role: curTitle || (pr.headline || '').split(/ at | \| /)[0] || '',
      company: curCompany,
      email: String(liEmail || '').trim(), phone: String(liPhone || '').trim(),
      salary: String(liSalary || '').trim(),
      location: (pr.location && pr.location.displayName) || '',
      linkedin: recruiterUrl,
      public_url: pr.publicProfileUrl || '',
      headline: pr.headline || '',
      skills: [], tags: [],
      source: 'linkedin-recruiter',
      open_to_work: !!mp.openToNewOpportunities,
      photo_url: photoUrl, cv_available: false,
      exp_years: expYears,
      experience: expYears != null ? (expYears + 'y') : '',
      notice_period: noticeLabel,
      pref_locations: prefLocations,
      // ── Full detail set (for the candidates DB table) ──────────────────────
      details: {
        ts_profile_id: tsId || '',
        public_url: pr.publicProfileUrl || '',
        industry: pr.industryName || '',
        network_distance: pr.networkDistance || '',
        current_title: curTitle,
        current_company: curCompany,
        current_start: cp.startDateOn || cp.startDate || null,
        exp_years: expYears,
        summary: pr.summary || '',
        num_connections: pr.numConnections || null,
        notice_period: noticeLabel,
        job_seeking_urgency: mp.jobSeekingUrgencyLevel || '',
        open_to_remote: !!mp.openToWorkRemotely,
        pref_locations: prefLocations,
        pref_titles: Array.isArray(mp.titles) ? mp.titles : [],
        employment_types: Array.isArray(mp.employmentTypes) ? mp.employmentTypes : [],
        positions: positions.map(p => ({
          title: p.title || '', company: p.companyName || '',
          start: p.startDateOn || p.startDate || null,
          location: (p.location && p.location.displayName) || '',
        })),
        work_history: groups.map(g => ({
          company: (g.companyUrnResolutionResult && g.companyUrnResolutionResult.name) ||
                   ((g.positions || [])[0] || {}).companyName || '',
          start: g.startDateOn || null, end: g.endDateOn || null,
          roles: (g.positions || []).map(p => ({
            title: p.title || '', start: p.startDateOn || null, end: p.endDateOn || null,
          })),
        })),
        educations: (pr.educations || []).map(ed => ({
          school: ed.schoolName || '', degree: ed.degreeName || '',
          field: ed.fieldOfStudy || '', start: ed.startDateOn || null,
        })),
        open_to_work: !!mp.openToNewOpportunities,
        photo_url: photoUrl, resume_url: '',
        qualifications: Object.keys(qualifications).length ? qualifications : null,
      },
      raw: e,                                            // full search-hit record
    });
  }
  return out;
}

// Runs in the profile page's MAIN world. Scrapes email + phone from the rendered
// LinkedIn Recruiter profile (search hits never contain contact info). Mirrors the
// old git-actions scraper: data-anonymize attrs, mailto:, then a text-node walk.
function scrapeLiContactDom() {
  const emailRe = /^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$/;
  const phoneRe = /^\+?[0-9][0-9 \-]{8,14}[0-9]$/;
  let email = '';
  const anEl = document.querySelector('[data-anonymize="email"]');
  if (anEl) email = (anEl.innerText || anEl.textContent || '').trim();
  if (!email) { const ml = document.querySelector('a[href^="mailto:"]'); if (ml) email = ml.href.replace('mailto:', '').split('?')[0].trim(); }
  if (!email) { const ei = document.querySelector('input[type="email"]'); if (ei && ei.value) email = ei.value.trim(); }
  if (!email) {
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    let n; while ((n = w.nextNode())) { const t = n.textContent.trim(); if (emailRe.test(t) && !t.toLowerCase().includes('linkedin')) { email = t; break; } }
  }
  if (!email) { const m = (document.body.innerText || '').slice(0, 3000).match(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/); if (m && !/linkedin|naukri/i.test(m[0])) email = m[0]; }
  let phone = '';
  const anPhone = document.querySelector('[data-anonymize="phone"],[data-anonymize="phone-number"]');
  if (anPhone) phone = (anPhone.innerText || anPhone.textContent || '').replace(/\s*\(.*?\)\s*/g, ' ').trim();
  if (!phone) {
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    let n; while ((n = w.nextNode())) { const t = n.textContent.replace(/\s*\(.*?\)\s*/g, ' ').trim(); if (phoneRe.test(t)) { phone = t; break; } }
  }

  // Open-to-work preferences (Notice period + preferred Locations). Find the value
  // that sits next to a label in the rendered profile. Try a DOM-label lookup first,
  // then fall back to a regex over the section's innerText.
  function valueForLabel(label) {
    const els = Array.from(document.querySelectorAll('h3,h4,dt,span,div,p,strong'));
    const lab = els.find(e => (e.innerText || e.textContent || '').trim().toLowerCase() === label.toLowerCase());
    if (!lab) return '';
    // value is usually the next sibling, or the next element in the parent.
    let v = lab.nextElementSibling;
    if (!v && lab.parentElement) v = lab.parentElement.nextElementSibling;
    const txt = v && (v.innerText || v.textContent || '').trim();
    return txt || '';
  }
  let notice = valueForLabel('Notice period');
  let jobType = valueForLabel('Job type');
  let expSalary = valueForLabel('Expected annual salary') || valueForLabel('Expected salary');
  let locations = '';
  // Preferred locations: collect the lines under the "Locations" label (On-site / Remote).
  const locLab = Array.from(document.querySelectorAll('h3,h4,dt,span,div,p,strong'))
    .find(e => (e.innerText || e.textContent || '').trim().toLowerCase() === 'locations');
  if (locLab) {
    let v = locLab.nextElementSibling || (locLab.parentElement && locLab.parentElement.nextElementSibling);
    if (v) locations = (v.innerText || v.textContent || '').replace(/\s*\n\s*/g, ' ').trim();
  }
  // Regex fallback over visible text.
  const body = (document.body.innerText || '');
  if (!notice) { const m = body.match(/Notice period\s*\n\s*([^\n]+)/i); if (m) notice = m[1].trim(); }
  if (!jobType) { const m = body.match(/Job type\s*\n\s*([^\n]+)/i); if (m) jobType = m[1].trim(); }
  if (!expSalary) { const m = body.match(/Expected (?:annual )?salary\s*\n\s*([^\n]+)/i); if (m) expSalary = m[1].trim(); }
  if (!locations) {
    const m = body.match(/Locations\s*\n([\s\S]{0,300}?)(?:\n\s*Workplace types|\n\s*Experience|\n\n)/i);
    if (m) locations = m[1].replace(/\s*\n\s*/g, ' ').trim();
  }
  // Trim a too-long location blob to keep cards tidy.
  if (locations.length > 200) locations = locations.slice(0, 200).trim() + '…';

  // Profile photo (avatar). Only accept a real https image (never a data: placeholder
  // / default avatar / the profile page URL). LinkedIn LAZY-LOADS avatars, so the real
  // URL often sits in data-delayed-url / srcset, not src yet — check all of them.
  let photo = '';
  const isRealPhoto = (u) => typeof u === 'string' && u.indexOf('http') === 0 &&
    /media\.licdn|dms\/image|displayphoto|profile-photo|headshot|profile-displayphoto/i.test(u);
  const imgUrl = (im) => {
    const cands = [im.currentSrc, im.src, im.getAttribute('data-delayed-url'),
                   im.getAttribute('data-ghost-url'), im.getAttribute('data-src')];
    const ss = im.getAttribute('srcset') || im.srcset || '';
    if (ss) cands.push(ss.split(',')[0].trim().split(' ')[0]);
    return cands.find(isRealPhoto) || '';
  };
  const allImgs = Array.from(document.querySelectorAll('img'));
  const ph = document.querySelector('img[data-anonymize="headshot-photo"]');
  if (ph) photo = imgUrl(ph);
  if (!photo) { for (const im of allImgs) { const u = imgUrl(im); if (u) { photo = u; break; } } }
  if (!photo) {
    for (const el of Array.from(document.querySelectorAll('[style*="background-image"]'))) {
      const m = (el.style.backgroundImage || '').match(/url\(["']?(https?:\/\/[^"')]+)["']?\)/);
      if (m && isRealPhoto(m[1])) { photo = m[1]; break; }
    }
  }
  // Debug: if still nothing, surface what image URLs ARE on the page so we can fix the match.
  let photoDebug = '';
  if (!photo) {
    photoDebug = allImgs.slice(0, 14)
      .map(im => (im.currentSrc || im.src || im.getAttribute('data-delayed-url') || ''))
      .filter(Boolean).map(u => u.slice(0, 70)).join(' || ').slice(0, 600);
  }
  // Attached resume / CV link, if the profile has one.
  let resume = '';
  const a = Array.from(document.querySelectorAll('a[href]'))
    .find(el => /attachment|ambry|dms-uploads|\.pdf($|\?)|\.docx?($|\?)/i.test(el.href || ''));
  if (a) resume = a.href;

  // Full Experience + Education sections (the profile page renders ALL entries, i.e.
  // the "Show all (13)" / "Show all (4)" from the search card). Grab the section text.
  function sectionText(name) {
    const h = Array.from(document.querySelectorAll('h2,h3,h4'))
      .find(e => (e.textContent || '').trim().toLowerCase() === name.toLowerCase());
    if (!h) return '';
    const sec = h.closest('section') || h.parentElement;
    if (!sec) return '';
    let t = (sec.innerText || sec.textContent || '').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
    t = t.replace(new RegExp('^' + name + '\\s*', 'i'), '').trim();
    return t.slice(0, 3000);
  }
  const experience = sectionText('Experience');
  const education = sectionText('Education');

  // Total years of experience = UNION of all "MMM YYYY – MMM YYYY / Present" date
  // ranges in the Experience section (merging overlaps so a company total + its
  // sub-roles aren't double-counted). Also grab the current (Present) company.
  let expYears = null, currentCompany = '';
  {
    const MONTHS = { jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5, jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11 };
    const now = new Date(); const nowM = now.getFullYear() * 12 + now.getMonth();
    const re = /([A-Za-z]{3})[a-z]*\.?\s+(\d{4})\s*(?:–|-|—|to)\s*(present|[A-Za-z]{3}[a-z]*\.?\s+\d{4})/gi;
    const ivs = []; let m;
    while ((m = re.exec(experience))) {
      const sM = parseInt(m[2], 10) * 12 + (MONTHS[m[1].slice(0, 3).toLowerCase()] || 0);
      let eM;
      if (/present/i.test(m[3])) eM = nowM;
      else { const em = m[3].match(/([A-Za-z]{3})[a-z]*\.?\s+(\d{4})/); eM = em ? parseInt(em[2], 10) * 12 + (MONTHS[em[1].slice(0, 3).toLowerCase()] || 0) : sM; }
      if (eM >= sM) ivs.push([sM, eM]);
    }
    if (ivs.length) {
      ivs.sort((a, b) => a[0] - b[0]);
      let tot = 0, cs = ivs[0][0], ce = ivs[0][1];
      for (let i = 1; i < ivs.length; i++) {
        const [s, e] = ivs[i];
        if (s <= ce) { if (e > ce) ce = e; } else { tot += ce - cs; cs = s; ce = e; }
      }
      tot += ce - cs;
      expYears = Math.round((tot / 12) * 10) / 10;
    }
    // Current company: the "Company · Type" line just above the first "Present" date.
    const lines = experience.split('\n').map(s => s.trim()).filter(Boolean);
    const pIdx = lines.findIndex(l => /present/i.test(l));
    if (pIdx > 0) {
      for (let i = pIdx - 1; i >= 0 && i >= pIdx - 3; i--) {
        if (lines[i].includes('·')) { currentCompany = lines[i].split('·')[0].trim(); break; }
      }
    }
  }

  return { email, phone, notice, jobType, expSalary, locations, photo, photoDebug, resume, experience, education, expYears, currentCompany };
}

// Visit each candidate's Recruiter profile and scrape email/phone (as the old
// GitHub-actions runner did). Navigates the SAME tab in the background.
async function enrichLiContacts(tab, candidates) {
  let got = 0;
  for (const c of candidates) {
    const url = c.linkedin || '';
    if (url.indexOf('/talent/profile/') === -1) continue;
    try {
      await randDelay(1500, 3800);                    // randomized human-like gap (varies each open: ~1.5–3.8s)
      await chrome.tabs.update(tab.id, { url });
      await waitForTabComplete(tab.id);
      await randDelay(1000, 2200);                    // let contact info render + look human (varies ~1–2.2s)
      const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: scrapeLiContactDom });
      const d = r && r.result;
      if (d) {
        if (d.email) c.email = d.email;
        if (d.phone) c.phone = d.phone;
        if (d.notice) c.notice_period = d.notice;
        if (d.jobType) c.job_type = d.jobType;
        if (d.expSalary) c.expected_salary = d.expSalary;
        if (d.locations) c.pref_locations = d.locations;
        if (d.photo) { c.photo_url = d.photo; if (c.details) c.details.photo_url = d.photo; }
        else if (d.photoDebug && !_liPhotoDbgLogged) { _liPhotoDbgLogged = true; await log('LI photo none; imgs: ' + d.photoDebug); }
        if (d.resume) { c.resume_url = d.resume; c.cv_available = true; if (c.details) c.details.resume_url = d.resume; }
        // Prefer the API's tenure-summed value (structured dates); only let the DOM
        // scrape fill experience when the rich projection didn't provide it.
        if (d.expYears != null && c.exp_years == null) {
          c.exp_years = d.expYears;
          if (!c.experience) c.experience = `${d.expYears}y`;
          if (c.details) c.details.exp_years = d.expYears;
        }
        if (d.currentCompany && !c.company) {
          c.company = d.currentCompany;
          if (c.details) c.details.current_company = d.currentCompany;
        }
        if (c.details) {
          if (d.experience) c.details.experience_full = d.experience;
          if (d.education) c.details.education_full = d.education;
        }
        if (d.email || d.phone) got++;
      }
    } catch (e) { /* skip this profile */ }
  }
  await log(`LinkedIn: enriched contact info for ${got}/${candidates.length}`);
  return candidates;
}

async function ensureLinkedInTab() {
  return ensureTabOnHost(['https://www.linkedin.com/talent/*', 'https://www.linkedin.com/*'],
    'https://www.linkedin.com/talent/', 'www.linkedin.com', 2500);
}

// Regular LinkedIn (Voyager) doesn't need Recruiter — use any logged-in www.linkedin.com
// tab, opening the feed (loads for every account, unlike /talent which needs a seat).
async function ensureLinkedInFeedTab() {
  return ensureTabOnHost(['https://www.linkedin.com/*'],
    'https://www.linkedin.com/feed/', 'www.linkedin.com', 2500);
}

// ── Assisted DM: open the candidate's LinkedIn message box PRE-FILLED with the draft.
// We never click Send — the recruiter reviews and sends (human-in-the-loop, safer). ──
// Runs in the profile page (MAIN world): click Message/InMail, then fill the compose box.
function liComposeFill(message) {
  function visible(el) { return el && el.offsetParent !== null; }
  function findMsgButton() {
    const sels = ['button[aria-label^="Message" i]', 'button[aria-label*="Send message" i]',
                  'a[aria-label*="Message" i]', 'button[aria-label*="InMail" i]'];
    for (const s of sels) { const b = document.querySelector(s); if (visible(b)) return b; }
    return Array.from(document.querySelectorAll('button,a'))
      .find(b => visible(b) && /^(message|inmail|send inmail)$/i.test((b.innerText || '').trim()));
  }
  function findBox() {
    const sels = ['div.msg-form__contenteditable', 'div[contenteditable="true"][role="textbox"]',
                  'textarea[name="message"]', 'textarea[placeholder*="message" i]',
                  'div.msg-overlay-conversation-bubble div[contenteditable="true"]'];
    for (const s of sels) { const b = document.querySelector(s); if (visible(b)) return b; }
    return null;
  }
  function nonEmpty(box) {
    const t = (box.tagName === 'TEXTAREA' ? box.value : (box.innerText || box.textContent || '')).trim();
    return t.length > 0;
  }
  function fill(box) {
    try {
      box.focus();
      if (box.tagName === 'TEXTAREA') {
        box.value = message;
        box.dispatchEvent(new Event('input', { bubbles: true }));
        return nonEmpty(box);
      }
      // contenteditable (LinkedIn uses a Quill/Draft editor). Put the caret in the box.
      const sel = window.getSelection(); const range = document.createRange();
      range.selectNodeContents(box); range.collapse(false); sel.removeAllRanges(); sel.addRange(range);
      // (1) Synthetic paste — most reliable for Quill/Draft (they handle the paste event
      // and insert text the React-controlled way).
      try {
        const dt = new DataTransfer(); dt.setData('text/plain', message);
        box.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
      } catch (e) {}
      // (2) execCommand insertText fallback.
      if (!nonEmpty(box)) {
        const s2 = window.getSelection(); const r2 = document.createRange();
        r2.selectNodeContents(box); s2.removeAllRanges(); s2.addRange(r2);
        try { document.execCommand('insertText', false, message); } catch (e) {}
      }
      // (3) Direct DOM fallback.
      if (!nonEmpty(box)) {
        box.innerHTML = ''; const p = document.createElement('p'); p.textContent = message; box.appendChild(p);
      }
      // Nudge React/Quill listeners so the Send button enables and the draft persists.
      box.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: message }));
      box.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
      return nonEmpty(box);
    } catch (e) { return false; }
  }
  // The profile's overflow "More" (…) button — on 3rd-degree profiles "Message" is
  // often hidden inside this menu rather than shown as a top-level button.
  function findMoreButton() {
    const sels = ['button[aria-label*="More actions" i]', 'button[aria-label="More" i]'];
    for (const s of sels) { const b = document.querySelector(s); if (visible(b)) return b; }
    return Array.from(document.querySelectorAll('button'))
      .find(b => visible(b) && /^more$/i.test((b.innerText || '').trim()));
  }
  // The "Message" entry inside the opened More dropdown.
  function findMenuMessageItem() {
    const scope = document.querySelector('.artdeco-dropdown__content') || document;
    let el = scope.querySelector('[aria-label^="Message" i]');
    if (visible(el)) return el;
    const cand = Array.from(scope.querySelectorAll('div,span,a,button,li'))
      .find(n => visible(n) && /^message\b/i.test((n.innerText || '').trim()) && (n.innerText || '').trim().length < 40);
    return cand ? (cand.closest('[role="button"],a,button,li') || cand) : null;
  }
  // Poll up to ~20s: the profile is a SPA, so the Message button and the compose box
  // can both appear well after load. Click the button when it shows; fill the box when
  // it shows. (One-shot timing was why it just opened the profile without a draft.)
  // If there's no direct Message button (common on 3rd-degree), open the "More" menu
  // and click the Message entry inside it.
  return new Promise((resolve) => {
    const deadline = Date.now() + 20000;
    let clicked = false, openedMore = false, moreAt = 0;
    let fillTries = 0;
    const iv = setInterval(() => {
      const box = findBox();
      if (box) {
        // Retry fill a few times — the editor may not accept input on the very first
        // tick after it mounts. Only declare success once text actually stuck.
        if (fill(box)) { clearInterval(iv); resolve('filled'); return; }
        if (++fillTries > 8) { clearInterval(iv); resolve('no-fill'); return; }
        return;                                         // box present but not filled yet — keep trying
      }
      if (!clicked) {
        const b = findMsgButton();
        if (b) { b.click(); clicked = true; }
        else if (!openedMore) {
          const more = findMoreButton();
          if (more) { more.click(); openedMore = true; moreAt = Date.now(); }
        } else {
          const item = findMenuMessageItem();
          if (item) { item.click(); clicked = true; }
          else if (Date.now() - moreAt > 3000) { openedMore = false; }  // menu yielded nothing; retry direct
        }
      }
      if (Date.now() > deadline) { clearInterval(iv); resolve(clicked ? 'no-compose' : 'no-button'); }
    }, 500);
  });
}

async function openDmCompose(url, message, name) {
  if (!url) { await log('open-dm: no profile URL'); return; }
  const u = url.indexOf('http') === 0 ? url : ('https://www.linkedin.com' + url);
  let tab;
  try { tab = await chrome.tabs.create({ url: u, active: true }); }   // focused so recruiter sees it
  catch (e) { await log('open-dm: could not open tab: ' + e.message); return; }
  await waitForTabComplete(tab.id);
  await randDelay(1500, 3000);
  let status = 'no-compose';
  try {
    const [r] = await chrome.scripting.executeScript({
      target: { tabId: tab.id }, world: 'MAIN', func: liComposeFill, args: [message] });
    status = (r && r.result) || 'no-compose';
  } catch (e) { await log('open-dm fill error: ' + e.message); }
  // Always copy the draft to clipboard as a fallback (recruiter can paste if auto-fill missed).
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id }, world: 'MAIN',
      func: (m) => { try { navigator.clipboard.writeText(m); } catch (e) {} }, args: [message] });
  } catch (e) {}
  await log(`open-dm: ${status === 'filled' ? 'pre-filled' : 'opened (draft on clipboard)'} compose for ${name || u}`);
}

// Resolve the per-search context (csrf + geo + exclude-company) ONCE so we can
// reuse it across paginated page fetches without re-running the typeaheads.
async function liSearchContext(tab, job) {
  const csrf = await liCsrfToken();
  if (!csrf) return { ok: false, error: 'no JSESSIONID (log into LinkedIn Recruiter)' };
  // Include location(s): the JD may list several (e.g. "Bangalore/Noida/Pune/Mumbai/Chennai").
  // Resolve EACH to a geo and include them all (candidates in ANY of them match).
  const geos = [];
  const loc = String((job.params || {}).location || '').trim();
  if (loc && loc.toLowerCase() !== 'not specified') {
    const locParts = loc.split(/[\/,|]/).map(s => s.trim()).filter(Boolean).slice(0, 8);
    for (const part of locParts) {
      await randDelay(800, 2000);
      const g = await resolveLiGeo(tab.id, part, csrf);
      if (g && g.id) { geos.push(g); await log(`LinkedIn location "${part}" -> ${g.id} (${g.displayName})`); }
      else await log(`LinkedIn location "${part}": no geo match`);
    }
  }
  let company = null;
  const excl = String((job.params || {}).exclude_company || '').trim();
  if (excl) {
    await randDelay(800, 2000);
    company = await resolveLiCompany(tab.id, excl, csrf);
    await log(company ? `LinkedIn exclude "${excl}" -> ${company.id} (${company.name})`
                      : `LinkedIn exclude "${excl}": no company match`);
  }
  // Excluded locations (JD said "except Mumbai") -> resolve each to a geo and exclude it
  // in the search via a negated BING_GEO_SWR value.
  const excludeGeos = [];
  for (const c of ((job.params || {}).exclude_locations || []).slice(0, 5)) {
    const name = String(c || '').trim();
    if (!name) continue;
    await randDelay(800, 2000);
    const g = await resolveLiGeo(tab.id, name.split(/[/,|]/)[0].trim(), csrf);
    if (g && g.id) { excludeGeos.push(g); await log(`LinkedIn exclude location "${name}" -> ${g.id} (${g.displayName})`); }
    else await log(`LinkedIn exclude location "${name}": no geo match`);
  }
  return { ok: true, csrf, geos, company, excludeGeos };
}

// Fetch ONE page of a recruiter search using a resolved context. start/count paginate.
async function liSearchPage(tab, job, ctx, start, count) {
  const headers = {
    'accept': 'application/json',
    'content-type': 'application/x-www-form-urlencoded',
    'csrf-token': ctx.csrf,
    'x-restli-protocol-version': '2.0.0',
    'x-http-method-override': 'GET',
  };
  async function attempt(minimal) {
    const liBody = buildLiBody(job, ctx.geos, ctx.company, { start, count, minimalDecoration: minimal, excludeGeos: ctx.excludeGeos });
    await randDelay(1800, 4200);                     // randomized human-like pause before each page (~1.8–4.2s)
    const [res] = await chrome.scripting.executeScript({
      target: { tabId: tab.id }, world: 'MAIN', func: liPageFetch,
      args: [LI_SEARCH_URL, headers, liBody],
    });
    return { r: res && res.result, liBody };
  }
  let { r, liBody } = await attempt(false);          // rich projection first
  // A bad/over-rich field projection 4xxs the whole search. If that happens (and it's
  // not an auth/contract issue), retry once with the minimal projection so experience
  // enrichment can never take search down with it.
  if (r && r.status && (r.status < 200 || r.status >= 300) &&
      r.status !== 401 && r.status !== 403 && r.status !== 307) {
    await log(`LinkedIn search ${r.status} with rich projection — retrying minimal decoration`);
    const retry = await attempt(true);
    if (retry.r) { r = retry.r; liBody = retry.liBody; }
  }
  if (!r) return { ok: false, error: 'no response from page fetch' };
  // Diagnostic: on any non-2xx, log the query string we sent (e.g. 422 = bad query).
  if (r.status && (r.status < 200 || r.status >= 300)) {
    const qm = /query=([^&]*)/.exec(liBody);
    const dq = decodeURIComponent(qm ? qm[1] : liBody);
    await log(`LinkedIn search ${r.status}; querylen=${dq.length}`);
    for (let i = 0; i < dq.length; i += 700) await log('LIQ: ' + dq.slice(i, i + 700));
  }
  if (r.status === 401 || r.status === 403) return { ok: false, error: `LinkedIn ${r.status} (re-login in Recruiter)` };
  // 307 = no active full-Recruiter contract for this session.
  if (r.status === 307) return { ok: false, error: 'LinkedIn Recruiter session not active — open linkedin.com/talent, let it fully load (run one search manually), then retry. If you only have Recruiter Lite (no full Recruiter seat), recruiter search isn\'t available.' };
  if (!r.ok) return { ok: false, error: `LinkedIn API HTTP ${r.status}: ${(r.text || '').slice(0, 200)}` };
  let data; try { data = JSON.parse(r.text); } catch (e) { return { ok: false, error: 'bad JSON from LinkedIn' }; }
  // Harvest the contract id from the response so project IMPORT can build a project URN
  // from a numeric id alone. The contract appears in nearly every talent API response.
  try { const cm = /ts_contract:(\d+)/.exec(r.text); if (cm) chrome.storage.local.set({ liContract: cm[1] }); } catch (e) {}
  return { ok: true, data };
}

// Run the LinkedIn Recruiter search (single page); returns { ok, data, geo, csrf, company }.
async function liRunSearch(tab, job) {
  const ctx = await liSearchContext(tab, job);
  if (!ctx.ok) return ctx;
  const p = await liSearchPage(tab, job, ctx, 0, Math.min(job.limit || 25, 50));
  if (!p.ok) return p;
  return { ok: true, data: p.data, geos: ctx.geos, csrf: ctx.csrf, company: ctx.company };
}

// How many JD skills appear anywhere in a candidate's text (headline/role/company/skills).
// Used to drop irrelevant (0-match) profiles so we don't enrich/save them.
function liSkillMatchCount(c, skills) {
  if (!skills || !skills.length) return 1;          // no skills given -> never filter
  const hay = [c.headline || '', c.role || '', c.current_title || '', c.company || '',
    (Array.isArray(c.skills) ? c.skills.join(' ') : (c.skills || '')),
    (c.details && c.details.headline) || ''].join(' | ').toLowerCase();
  let n = 0;
  for (const s of skills) { const t = String(s || '').toLowerCase().trim(); if (t && hay.indexOf(t) !== -1) n++; }
  return n;
}

async function runLiJob(tab, job) {
  const ctx = await liSearchContext(tab, job);
  if (!ctx.ok) return ctx;
  // Paginate so EVERY matching candidate up to the requested count is saved (not just the
  // first page). Honors the "Fetch N candidates (max)" value, floored at 25, capped at
  // LI_MAX_RESULTS. We REQUEST 50/page (LinkedIn's max) but it may return fewer (often 25),
  // so we advance by the ACTUAL count returned and only stop on an empty page / the total /
  // the target — never assume a fixed page size (that would stop after one page).
  const want = Math.min(Math.max(job.limit || 25, 25), LI_MAX_RESULTS);
  const REQ = 50;
  let candidates = [], total = 0, start = 0, guard = 0;
  const seen = new Set();
  while (candidates.length < want && guard++ < 25) {
    const p = await liSearchPage(tab, job, ctx, start, REQ);
    if (!p.ok) { if (start === 0) return p; break; }  // first-page error fatal; later: stop
    if (!total) total = (p.data.metadata || {}).total || 0;
    const els = p.data.elements || [];
    if (!els.length) break;                            // truly no more results
    for (const c of parseLiElements(p.data, els.length)) {
      const k = c.public_url || c.linkedin || c.name;
      if (k && !seen.has(k)) { seen.add(k); candidates.push(c); }
    }
    start += els.length;                               // advance by what we actually got
    if (total && start >= total) break;                // fetched everything available
  }
  // Drop profiles with ZERO matching JD skills — don't keep/enrich/save irrelevant ones.
  const _jdSkills = (job.params && job.params.skills) || [];
  if (_jdSkills.length) {
    const _before = candidates.length;
    candidates = candidates.filter(c => liSkillMatchCount(c, _jdSkills) > 0);
    if (_before !== candidates.length) await log(`skill-filter: dropped ${_before - candidates.length} profile(s) with 0 matching skills`);
  }
  candidates = candidates.slice(0, want);
  // Visit each profile to scrape email/phone/resume (search hits don't include them). We
  // enrich up to the REQUESTED count ("Fetch N") — NO fixed 25 cap — so asking for 100 gets
  // 100 enriched. Each visit is ~5–12s, so large N is slow; that's the cost of full contact
  // data. (Experience/work-history for the "why a fit" summary already comes from the search
  // projection for ALL candidates, so it doesn't depend on this step.)
  const _enrichN = Math.min(Math.max(job.limit || 25, 1), candidates.length);
  if (_enrichN > 30) await log(`enriching ${_enrichN} profiles for contact info — this can take several minutes`);
  await enrichLiContacts(tab, candidates.slice(0, _enrichN));
  return { ok: true, candidates, total };
}

// ── Regular LinkedIn (Voyager people search) — runs in the user's own logged-in
// linkedin.com tab so every recruiter uses THEIR OWN account (no shared cookie). ──
function _liStrHasOtw(s) {
  const lc = (s || '').toLowerCase();
  return ['open to work', 'opentowork', '#opentowork', 'open_to_work'].some(k => lc.includes(k));
}
function _liDeepHasOtw(obj, depth) {
  if (!obj || typeof obj !== 'object' || (depth || 0) > 5) return false;
  const t = obj.$type || '';
  if (['OpenToWork', 'Openness', 'OpenForOpportunities'].some(k => t.includes(k))) return true;
  for (const bf of ['openToWork', 'openToOpportunities', 'openToCareerOpportunities', 'isOpenToWork', 'openForOpportunities'])
    if (obj[bf] === true) return true;
  for (const key of ['overlayType', 'overlayImageType', 'text', 'badgeText', 'accessibilityText', 'overlayText', 'label', 'value'])
    if (_liStrHasOtw(String(obj[key] || ''))) return true;
  for (const v of Object.values(obj)) {
    if (v && typeof v === 'object' && !Array.isArray(v) && _liDeepHasOtw(v, (depth || 0) + 1)) return true;
    if (Array.isArray(v)) for (const it of v) if (it && typeof it === 'object' && _liDeepHasOtw(it, (depth || 0) + 1)) return true;
  }
  return false;
}
function parseLiVoyager(data, limit, location) {
  const included = (data && data.included) || [];
  const otwById = {};
  for (const obj of included) {
    if (!obj || typeof obj !== 'object') continue;
    const t = obj.$type || '';
    const nav = obj.navigationUrl || '';
    const m = nav.match(/\/in\/([\w-]+)/);
    const slug = (obj.publicIdentifier || obj.vanityName || (m ? m[1] : '') || '');
    if (slug && _liDeepHasOtw(obj, 0)) otwById[slug] = true;
  }
  // Location filter. Country-level targets (India/blank) pass everyone through (the
  // results are already broad); a specific city/region keeps only candidates whose
  // location matches it. Candidates with NO location are kept (don't over-drop).
  const locLc = String(location || '').trim().toLowerCase();
  const countryLevel = !locLc || ['india', 'in', 'bharat', 'not specified', 'none'].includes(locLc);
  // Match on the leading city/region token (e.g. "Hyderabad" out of "Hyderabad, Telangana, India").
  const locTokens = countryLevel ? [] : locLc.split(/[\/,|]/).map(s => s.trim()).filter(Boolean);
  const locMatches = (candLoc) => {
    if (countryLevel) return true;
    const cl = (candLoc || '').toLowerCase().trim();
    if (!cl) return true;                              // unknown location -> keep
    return locTokens.some(t => cl.includes(t) || t.includes(cl.split(',')[0].trim()));
  };

  const out = [], seen = new Set();
  let dropped = 0;
  for (const obj of included) {
    if (!obj || typeof obj !== 'object') continue;
    if (!String(obj.$type || '').includes('EntityResultViewModel')) continue;
    const name = ((obj.title && obj.title.text) || '').trim();
    if (!name || seen.has(name)) continue;
    seen.add(name);
    const headline = ((obj.primarySubtitle && obj.primarySubtitle.text) || '').trim();
    // The candidate's REAL location is in secondarySubtitle (e.g. "Hyderabad, Telangana, India").
    // Do NOT fall back to the job's search location — that mislabels everyone.
    const candLoc = ((obj.secondarySubtitle && obj.secondarySubtitle.text) || '').trim();
    if (!locMatches(candLoc)) { dropped++; continue; } // location filter
    const nav = obj.navigationUrl || '';
    const m = nav.match(/\/in\/([\w-]+)/);
    const pubId = m ? m[1] : '';
    let role = headline, company = '';
    const at = headline.match(/\s+(?:at|@)\s+/i);
    if (at) { role = headline.slice(0, at.index).trim(); company = headline.slice(at.index + at[0].length).trim(); }
    const otw = otwById[pubId] || _liStrHasOtw(headline);
    out.push({
      name, role, company, email: '', phone: '', salary: '',
      location: candLoc,
      linkedin: pubId ? `https://www.linkedin.com/in/${pubId}` : nav,
      public_url: pubId ? `https://www.linkedin.com/in/${pubId}` : nav,
      headline, skills: [], tags: [], source: 'linkedin', open_to_work: !!otw,
    });
    if (out.length >= (limit || 25)) break;
  }
  if (!countryLevel) log(`LinkedIn regular: location "${location}" kept ${out.length}, dropped ${dropped}`);
  return out;
}
// Resolve a city/country NAME to a PUBLIC geo id (the geoUrn used by regular LinkedIn
// people search, e.g. India -> 102713980) via the Voyager geo typeahead. Returns the
// numeric id string, or '' if it can't resolve (caller then falls back to client filter).
async function resolveVoyagerGeo(tabId, city, csrf) {
  if (!city) return '';
  const headers = {
    'accept': 'application/vnd.linkedin.normalized+json+2.1',
    'csrf-token': csrf, 'x-restli-protocol-version': '2.0.0', 'x-li-lang': 'en_US',
  };
  const url = 'https://www.linkedin.com/voyager/api/typeaheadHits?q=type&type=GEO&useCase=PEOPLE_SEARCH' +
    '&keywords=' + encodeURIComponent(city);
  let res;
  try { [res] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: liPageGet, args: [url, headers] }); }
  catch (e) { return ''; }
  const r = res && res.result;
  if (!r || !r.ok) return '';
  let data; try { data = JSON.parse(r.text); } catch (e) { return ''; }
  const els = data.elements || (data.data && data.data.elements) || [];
  const cl = city.toLowerCase();
  const idOf = e => {
    const urn = e.targetUrn || e.objectUrn || ((e.target && e.target.geoUrn)) || '';
    const m = String(urn).match(/(\d+)\s*$/);
    return m ? m[1] : '';
  };
  const txtOf = e => ((e.text && e.text.text) || e.displayText || '').toLowerCase();
  const pick = els.find(e => txtOf(e).startsWith(cl)) || els.find(e => txtOf(e).includes(cl)) || els[0];
  return pick ? idOf(pick) : '';
}

async function runLiRegularJob(tab, job) {
  const csrf = await liCsrfToken();
  if (!csrf) return { ok: false, error: 'no JSESSIONID (log into LinkedIn)' };
  const kw = encodeURIComponent(job.query || (job.params && job.params.title) || '');
  // Server-side location filter: resolve the location to a public geo id and add it as
  // a geoUrn queryParameter (mirrors the faceted-search URL geoUrn=["<id>"]). Country-
  // level / blank locations skip this (results are already broad).
  const locRaw = String((job.params && job.params.location) || '').trim();
  const locLcRaw = locRaw.toLowerCase();
  const isCountryLevel = !locRaw || ['india', 'in', 'bharat', 'not specified', 'none'].includes(locLcRaw);
  let geoId = '';
  if (locRaw && !['not specified', 'none'].includes(locLcRaw)) {
    await randDelay(800, 2000);
    geoId = await resolveVoyagerGeo(tab.id, locRaw.split(/[\/,|]/)[0].trim(), csrf);
    await log(geoId ? `LinkedIn regular: location "${locRaw}" -> geoUrn ${geoId}`
                    : `LinkedIn regular: location "${locRaw}" not resolved (client-side filter only)`);
  }
  const geoParam = geoId ? `,(key:geoUrn,value:List(${geoId}))` : '';
  const url = 'https://www.linkedin.com/voyager/api/graphql' +
    '?variables=(start:0,origin:' + (geoId ? 'FACETED_SEARCH' : 'GLOBAL_SEARCH_HEADER') + ',query:(keywords:' + kw +
    ',flagshipSearchIntent:SEARCH_SRP,queryParameters:List((key:resultType,value:List(PEOPLE))' + geoParam + '),' +
    'includeFiltersInResponse:false))' +
    '&queryId=voyagerSearchDashClusters.b0928897b71bd00a5a7291755dcd64f0';
  const headers = {
    'accept': 'application/vnd.linkedin.normalized+json+2.1',
    'csrf-token': csrf,
    'x-restli-protocol-version': '2.0.0',
    'x-li-lang': 'en_US',
    'x-li-page-instance': 'urn:li:page:d_flagship3_search_srp_people;1',
  };
  // executeScript can throw "Cannot access contents of the page" if the tab isn't a
  // loaded, permitted LinkedIn page yet. Re-ensure the tab and retry before failing.
  let r = null;
  await randDelay(2000, 5000);                        // human-like pause before searching
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: liPageGet, args: [url, headers] });
      r = res && res.result;
      if (r) break;
    } catch (e) {
      await log(`LinkedIn regular: tab not ready (${e.message}); reopening LinkedIn tab...`);
    }
    const t = await ensureLinkedInFeedTab();
    if (t) tab = t;
    await new Promise(rs => setTimeout(rs, 1500));
  }
  if (!r) return { ok: false, error: 'could not run LinkedIn search in tab (open/refresh a linkedin.com tab and retry)' };
  if (r.status === 401 || r.status === 403) return { ok: false, error: `LinkedIn ${r.status} (log into linkedin.com)` };
  if (!r.ok) return { ok: false, error: `LinkedIn voyager HTTP ${r.status}: ${(r.text || '').slice(0, 160)}` };
  let data; try { data = JSON.parse(r.text); } catch (e) { return { ok: false, error: 'bad JSON from LinkedIn voyager' }; }
  // If geoUrn was applied server-side, results are already location-filtered — pass ''
  // so the client-side filter doesn't re-filter (and risk over-dropping on label format).
  const loc = geoId ? '' : ((job.params && job.params.location) || '');
  const candidates = parseLiVoyager(data, Math.min(job.limit || 25, LI_MAX_RESULTS), loc);
  return { ok: true, candidates, total: candidates.length };
}

// MAIN-world JSON POST (for create-project / batch-add). Returns {status, ok, text}.
function liPageJson(url, headers, bodyObj, methodOverride) {
  const h = Object.assign({ 'content-type': 'application/json; charset=UTF-8' }, headers);
  if (methodOverride) h['x-http-method-override'] = methodOverride;
  return fetch(url, { method: 'POST', credentials: 'include', headers: h, body: JSON.stringify(bodyObj) })
    .then(r => r.text().then(t => ({ status: r.status, ok: r.ok, text: t })))
    .catch(e => ({ status: 0, ok: false, text: String(e) }));
}

// Find an existing hiring project whose name EXACTLY matches `name`. Returns its
// entityUrn, or '' if none / on any error (caller then creates a new project).
// Defensive + diagnostic: tries a few finder shapes and logs the response so the
// exact field names can be confirmed from logs if LinkedIn's shape differs.
async function findExistingProjectByName(tab, baseHeaders, name) {
  const target = String(name || '').trim();
  if (!target) return '';
  const deco = '%28elements*%28entityUrn%2Cname%2ChiringProjectMetadata%28name%29%29%29';
  const urls = [
    'https://www.linkedin.com/talent/api/talentHiringProjects?q=hiringProjectsByCurrentMember&start=0&count=100&decoration=' + deco,
    'https://www.linkedin.com/talent/api/talentHiringProjects?q=hiringProjects&start=0&count=100&decoration=' + deco,
    'https://www.linkedin.com/talent/api/talentHiringProjects?start=0&count=100&decoration=' + deco,
  ];
  // Pull a project's display name from whatever field the API used.
  const nameOf = (el) => (el && (el.name
      || (el.hiringProjectMetadata && el.hiringProjectMetadata.name)
      || (el.hiringProjectMetadataResolutionResult && el.hiringProjectMetadataResolutionResult.name))) || '';
  let logged = false;
  for (const url of urls) {
    let res;
    try { [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: liPageGet, args: [url, baseHeaders] }); }
    catch (e) { continue; }
    const r = res && res.result;
    if (!r || !r.ok) continue;
    let d; try { d = JSON.parse(r.text); } catch (e) { continue; }
    const list = d.elements || (d.data && d.data.elements) || Object.values(d.results || {});
    if (!Array.isArray(list) || !list.length) continue;
    if (!logged) { logged = true; await log(`create-project: project list (${list.length}) e.g. "${nameOf(list[0])}"`); }
    const hit = list.find(el => nameOf(el).trim() === target);   // EXACT name match
    if (hit && hit.entityUrn) return hit.entityUrn;
  }
  return '';
}

// Create a Recruiter project + add the top OTW candidates. Heavily logged so we
// can confirm the project's sourcing-channel + pipeline-state on first run.
async function runCreateProject(tab, job) {
  const ctx = await liSearchContext(tab, job);
  if (!ctx.ok) return ctx;
  const csrf = ctx.csrf;
  const baseHeaders = { 'accept': 'application/json', 'csrf-token': csrf, 'x-restli-protocol-version': '2.0.0' };

  // Paginate the recruiter search to collect matching profiles. PAGE=50 (LinkedIn's max
  // per request) minimizes the number of search requests. For create-project, honor the
  // requested save count with a floor of 100 (a project minimum) and no 100 ceiling —
  // bounded at 500 as a safety stop so a typo can't trigger an enormous scrape.
  // (The candidate ADD step stays at 25/batch — larger batches 403 as oversized.)
  // Request 50/page (LinkedIn's max) but advance by the ACTUAL count returned — it often
  // returns 25, so a fixed page-size step would stop after one page and under-collect.
  const REQ = 50;
  const CAP = Math.min(Math.max(job.limit || 100, 100), 500);
  const picks = [];
  const seen = new Set();
  let candidates = [];
  let firstData = null, total = 0, start = 0, guard = 0;
  while (picks.length < CAP && guard++ < 30) {
    const p = await liSearchPage(tab, job, ctx, start, REQ);
    if (!p.ok) { if (start === 0) return p; break; }   // first-page error is fatal; later pages: stop
    if (!firstData) { firstData = p.data; total = (p.data.metadata || {}).total || 0; }
    const els = p.data.elements || [];
    if (!els.length) break;                             // truly no more results
    for (const e of els) {
      // entityUrn = urn:li:ts_hiring_candidate:(…,urn:li:ts_hire_identity:<id>)
      const m = String(e.entityUrn || '').match(/ts_hire_identity:(\d+)/);
      if (m) { const urn = 'urn:li:ts_hire_identity:' + m[1]; if (!seen.has(urn)) { seen.add(urn); picks.push(urn); } }
    }
    candidates = candidates.concat(parseLiElements(p.data, els.length));
    start += els.length;                                // advance by what we actually got
    if (total && start >= total) break;                 // fetched everything available
  }
  if (!firstData) return { ok: false, error: 'no results from recruiter search' };
  await log(`create-project: search total=${total}, collected ${picks.length} candidate ids across pages`);

  // SEARCH-ONLY mode (account add-quota paused): source the candidates into Scout but do
  // NOT create an empty LinkedIn project shell that can't be populated. Enrich + return.
  if ((job.params || {}).search_only) {
    await log('create-project: SEARCH-ONLY (add-quota paused) — saving candidates to Scout, skipping project creation');
    const _pn = (job.params || {}).project_name;
    // Post candidates now (fast), then enrich + re-post in the background.
    await postResults(job.callback_url, job.callback_token, job.search_id, candidates, null, null, 'create_project', _pn);
    const _eN = Math.min(candidates.length, Math.max(job.limit || 100, 100));
    if (_eN > 30) await log(`create-project: enriching ${_eN} profiles for contact info — several minutes`);
    await enrichLiContacts(tab, candidates.slice(0, _eN));
    await postResults(job.callback_url, job.callback_token, job.search_id, candidates, null, null, 'create_project', _pn);
    return { ok: true, alreadyPosted: true };
  }

  // 1) Resolve the target project. Reuse an existing project whose name EXACTLY
  //    matches (so re-running the same JR/title adds to it instead of duplicating);
  //    otherwise create a new one. Name uses project_name (may include the JR no).
  const p0 = job.params || {};
  const title = p0.project_name || p0.title || job.query || 'Scout Project';
  let projectUrn = '';
  try {
    projectUrn = await findExistingProjectByName(tab, baseHeaders, title);
    if (projectUrn) await log(`create-project: reusing existing project "${title}" -> ${projectUrn}`);
  } catch (e) { /* fall through to create */ }

  if (!projectUrn) {
    const meta = {
      name: title, rawTitleName: title, skills: [],
      state: 'ACTIVE', type: 'RECRUITER', projectVisibility: 'PRIVATE',
      hiringPipelineEnabled: false,
    };
    const _geoUrns = (ctx.geos || []).filter(g => g && g.id).map(g => 'urn:li:ts_geo:' + g.id);
    if (_geoUrns.length) meta.geoLocationsUrns = _geoUrns;
    const createBody = { attachDefaultCandidateHiringPipeline: true, hiringProjectMetadata: meta,
                         candidateCounts: [], approvalHistoryItems: [], customFieldValuesDecorated: [] };
    // decoration to (hopefully) get the project's sourcing channels back
    const createUrl = 'https://www.linkedin.com/talent/api/talentHiringProjects' +
      '?decoration=%28entityUrn%2CsourcingChannels*~%28entityUrn%2CchannelType%29%29';
    // Helper: one create attempt against a given URL.
    const tryCreate = async (url) => {
      const [c] = await chrome.scripting.executeScript({
        target: { tabId: tab.id }, world: 'MAIN', func: liPageJson, args: [url, baseHeaders, createBody, null] });
      return c && c.result;
    };
    // LinkedIn occasionally returns a transient 503/429/5xx on project creation.
    // Retry the create a few times with backoff before giving up.
    let cres = null;
    await randDelay(2000, 5000);                        // human-like pause before creating
    for (let attempt = 0; attempt < 4; attempt++) {
      cres = await tryCreate(createUrl);
      if (!cres || !cres.ok) cres = await tryCreate('https://www.linkedin.com/talent/api/talentHiringProjects'); // retry sans decoration
      if (cres && cres.ok) break;
      const st = cres ? cres.status : 0;
      if (!(st === 503 || st === 429 || st === 500 || st === 502 || st === 504 || st === 0)) break; // non-transient -> stop
      await log(`create-project: create ${st} (transient) — retrying in ${(attempt + 1) * 2}s`);
      await new Promise(r => setTimeout(r, (attempt + 1) * 2000));
    }
    if (!cres || !cres.ok) return { ok: false, error: `create project failed: ${cres ? cres.status + ' ' + cres.text.slice(0, 200) : 'no response'}` };
    await log(`create-project: create response ${cres.text.slice(0, 300)}`);
    let cdata; try { cdata = JSON.parse(cres.text); } catch (e) { return { ok: false, error: 'create project: bad JSON' }; }
    projectUrn = cdata.entityUrn || (cdata.value && cdata.value.entityUrn) || '';
    if (!projectUrn) return { ok: false, error: 'create project: no entityUrn in response' };
    await log(`create-project: created ${projectUrn}`);
  }
  // contract + project id from urn:li:ts_hiring_project:(urn:li:ts_contract:<C>,<P>)
  const m = projectUrn.match(/ts_contract:(\d+),(\d+)\)/);
  const contract = m ? m[1] : '';
  const projectId = m ? m[2] : '';
  const projectUrl = projectId ? `https://www.linkedin.com/talent/hire/${projectId}` : '';
  // Remember the contract id so project IMPORT can construct a project URN from just a
  // numeric project id (the /talent/hire/<id> URL) without a fragile lookup.
  if (contract) { try { await chrome.storage.local.set({ liContract: contract }); } catch (e) {} }

  // 2) Find the project's sourcing channels. Collect ALL of them in preference order
  //    (RECRUITER_SEARCH first, AUTOMATED last) — the add step tries each until one works,
  //    because a freshly-created project's "right" channel varies and a single guess 403s.
  const channelUrns = [];                              // ordered, de-duped
  const urnOf = (c) => c.entityUrn || c.entity || (c.entityCountUnion && c.entityCountUnion.sourcingChannel) || '';
  const addOrdered = (list) => {
    for (const c of list) { const u = urnOf(c); if (u) log(`  ch: ${u} type=${c.channelType}`); }
    const score = (c) => {
      const t = (c.channelType || '').toUpperCase();
      if (/^RECRUITER_SEARCH$/.test(t)) return 0;
      if (/RECRUITER_SEARCH/.test(t)) return 1;
      if (/MANUAL|RECRUITER/.test(t) && !/AUTOMATED/.test(t)) return 2;
      if (!/INTERNAL|APPLICANT|AUTOMATED|REDISCOVER/.test(t)) return 3;
      return 4;                                         // AUTOMATED/etc last — still tried
    };
    for (const c of [...list].sort((a, b) => score(a) - score(b))) {
      const u = urnOf(c); if (u && !channelUrns.includes(u)) channelUrns.push(u);
    }
  };
  // Source A: GET the project with a sourcingChannels decoration.
  {
    const gUrl = 'https://www.linkedin.com/talent/api/talentHiringProjects/' + encodeURIComponent(projectUrn) +
      '?altkey=urn&decoration=%28entityUrn%2CsourcingChannels*~%28entityUrn%2CchannelType%29%29';
    const [g] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: liPageGet, args: [gUrl, baseHeaders] });
    const gr = g && g.result;
    await log(`create-project: projGET ${gr ? gr.status : '?'} ${gr ? gr.text.slice(0, 300) : ''}`);
    if (gr && gr.ok) {
      try {
        const gd = JSON.parse(gr.text);
        const map = gd.sourcingChannelsResolutionResults || gd.sourcingChannels;
        addOrdered(Array.isArray(map) ? map : (map ? Object.values(map) : []));
      } catch (e) {}
    }
  }
  // Source B: the channels finder (adds any not already found).
  {
    const scUrl = 'https://www.linkedin.com/talent/api/talentSourcingChannels?q=hiringProject&count=25&hiringProject=' +
      encodeURIComponent(projectUrn);
    const [scr] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: liPageGet, args: [scUrl, baseHeaders] });
    const scres = scr && scr.result;
    await log(`create-project: channelsGET ${scres ? scres.status : '?'} ${scres ? scres.text.slice(0, 300) : ''}`);
    if (scres && scres.ok) {
      try {
        const sd = JSON.parse(scres.text);
        addOrdered(sd.elements || (sd.data && sd.data.elements) || Object.values(sd.results || {}));
      } catch (e) {}
    }
  }
  await log(`create-project: ${channelUrns.length} sourcing channel(s) to try`);

  // 3) Batch-add the candidates. This is a RestLi BATCH_CREATE — it MUST carry the
  //    x-restli-method: BATCH_CREATE header or LinkedIn 400s the {elements:[...]} body.
  //    Add in chunks so a large pool (hundreds) doesn't exceed batch limits.
  let addBlocked = false;   // set when LinkedIn forbids (403) the add on every channel = account add-quota hit
  if (picks.length && channelUrns.length) {
    const addHeaders = Object.assign({}, baseHeaders, { 'x-restli-method': 'BATCH_CREATE' });
    // 25 per batch = the batch size that worked on 1.0.3x/1.0.4x (a 100-element batch 403s).
    const CHUNK = 25;
    const addUrl = 'https://www.linkedin.com/talent/api/talentSourcingChannelCandidateCreations';
    // POST one chunk with a given channel. Returns {ok, status, text}.
    let _loggedAddBody = false;
    const postChunk = async (channel, hids) => {
      const elements = hids.map(hid => ({
        hiringContext: projectUrn, candidate: hid, sourcingChannel: channel,
        candidateAddedToANewProject: true, copiedFromAnotherProject: false,
      }));
      if (!_loggedAddBody) { _loggedAddBody = true; await log(`create-project: add payload sample -> ${JSON.stringify({ url: addUrl, headers: Object.keys(addHeaders), element0: elements[0] })}`); }
      const [ar] = await chrome.scripting.executeScript({
        target: { tabId: tab.id }, world: 'MAIN', func: liPageJson,
        args: [addUrl, addHeaders, { elements }, null] });
      return (ar && ar.result) || { ok: false, status: 0, text: '' };
    };
    let added = 0;
    let sourcingChannel = '';                          // the channel proven to work
    // Try one chunk across every candidate channel (locking onto the first that's
    // accepted). Returns the last response. 429/5xx back off + retry; 403 = try next channel.
    const tryAddChunk = async (i, hids) => {
      let ares = null;
      const tryChannels = sourcingChannel ? [sourcingChannel] : channelUrns;
      for (const ch of tryChannels) {
        for (let attempt = 0; attempt < 4; attempt++) {
          ares = await postChunk(ch, hids);
          const st = ares.status;
          if (ares.ok) break;
          if (!(st === 429 || st === 503 || st === 500 || st === 502 || st === 504)) break;
          const wait = 15000 * (attempt + 1);
          await log(`create-project: add chunk ${i}-${i + hids.length} ch=${ch.slice(-12)} -> ${st} (rate-limited) — waiting ${wait/1000}s`);
          await new Promise(r => setTimeout(r, wait));
        }
        if (ares.ok) { sourcingChannel = ch; return ares; }   // lock onto the working channel
        await log(`create-project: add chunk ${i}-${i + hids.length} ch=${ch.slice(-12)} -> ${ares.status} ${(ares.text || '').slice(0, 500)} — trying next channel`);
      }
      return ares;
    };
    // Let the search-burst rate window settle before the first write (avoids 429/403 throttles).
    await randDelay(8000, 14000);
    for (let i = 0; i < picks.length; i += CHUNK) {
      if (i > 0) await randDelay(4000, 8000);
      const hids = picks.slice(i, i + CHUNK);
      let ares = await tryAddChunk(i, hids);
      // If the FIRST write is forbidden on every channel, it's usually a transient
      // anti-automation throttle right after the search burst (not a permanent "wrong
      // channel"). Cool down and retry the channels ONCE before giving up.
      if (i === 0 && ares && !ares.ok && ares.status === 403) {
        await log('create-project: all channels 403 on first batch — cooling down 60s, then one retry');
        await new Promise(r => setTimeout(r, 60000));
        ares = await tryAddChunk(i, hids);
      }
      // Persistent 403 on the first batch across every channel = the account's
      // candidate-add quota is exhausted (a wall, not a wrong channel). Flag it so Scout
      // can pause the auto-pipeline and stop creating empty project shells.
      if (i === 0 && ares && !ares.ok && ares.status === 403) addBlocked = true;
      if (ares && ares.ok) added += hids.length;
      await log(`create-project: add chunk ${i}-${i + hids.length} -> ${ares ? ares.status : '?'}${sourcingChannel ? ' (ch ' + sourcingChannel.slice(-12) + ')' : ''}`);
      if (!sourcingChannel) break;                     // no channel worked — stop trying the rest
    }
    await log(`create-project: added ${added}/${picks.length} candidates to project`);
  } else {
    await log('create-project: skipped add (no channels found or no candidates)');
  }

  // 4) POST the project + candidates NOW so the user sees it created immediately — don't
  //    make them wait through enrichment (which can take minutes and would blow the
  //    frontend's create-project timeout).
  const _pn = (job.params || {}).project_name;
  await postResults(job.callback_url, job.callback_token, job.search_id, candidates, null, projectUrl, 'create_project', _pn, addBlocked);
  await log(`create-project: posted project + ${candidates.length} candidate(s); enriching contact info in background`);

  // 5) Enrich email/phone/resume for ALL reported candidates (up to the requested count),
  //    then re-post so Scout's DB picks up the contact info. The user already has the project.
  const _enrichN = Math.min(candidates.length, Math.max(job.limit || 100, 100));
  if (_enrichN > 30) await log(`create-project: enriching ${_enrichN} profiles for contact info — several minutes`);
  await enrichLiContacts(tab, candidates.slice(0, _enrichN));
  await postResults(job.callback_url, job.callback_token, job.search_id, candidates, null, projectUrl, 'create_project', _pn, addBlocked);
  await log('create-project: contact-info enrichment complete, Scout updated');

  return { ok: true, alreadyPosted: true };
}

// ── Import an existing project's candidate roster into the DB ─────────────────
// Lists a hiring project's candidates via the SAME talentRecruiterSearchHits endpoint
// used for search, but with q=pipelineSearch + a query/requestParams that reference the
// project URN (confirmed from a Recruiter network capture). Reuses parseLiElements since
// the hit shape (linkedInMemberProfileUrn~ resolution) is identical to recruiter search.
function buildPipelineBody(projectUrn, projectName, opts) {
  const urnEnc = liEncVal(projectUrn);
  const nameEnc = liEncVal(projectName || 'Project');
  // All candidates in the project, newest-activity first. Empty facetSelections =
  // no hiring-state restriction (every pipeline stage).
  const query = `(facetSelections:List(),facets:List(),capSearchSortBy:HIRING_CANDIDATE_LAST_UPDATED_DATE,` +
                `hiringProjects:List((text:${nameEnc},entity:${urnEnc})))`;
  const requestParams = `(hiringProject:${urnEnc},doFacetCounting:true,doFacetDecoration:true)`;
  const count = (opts && opts.count) || 25;
  const start = (opts && opts.start) || 0;
  const decoRaw = (opts && opts.minimalDecoration) ? LI_DECORATION_RAW : LI_DECORATION_RICH;
  return `decoration=${liEncDecoration(decoRaw)}&count=${count}&q=pipelineSearch` +
         `&query=${query}&requestParams=${requestParams}&start=${start}`;
}

// Resolve a project's full URN (with contract) + name from its numeric id (from the
// /talent/hire/<id> URL). Tries a couple of shapes; logs so we can confirm from logs.
async function resolveProjectUrn(tab, baseHeaders, projectId) {
  const urls = [
    'https://www.linkedin.com/talent/api/talentHiringProjects/' + projectId + '?decoration=%28entityUrn%2ChiringProjectMetadata%28name%29%29',
    'https://www.linkedin.com/talent/api/talentHiringProjects/' + projectId,
  ];
  for (const url of urls) {
    let res;
    try { [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: liPageGet, args: [url, baseHeaders] }); }
    catch (e) { continue; }
    const r = res && res.result;
    if (!r || !r.ok) { if (r) await log(`import: projectGET ${r.status}`); continue; }
    let d; try { d = JSON.parse(r.text); } catch (e) { continue; }
    const urn = d.entityUrn || (d.value && d.value.entityUrn) || '';
    const name = (d.hiringProjectMetadata && d.hiringProjectMetadata.name) ||
                 (d.value && d.value.hiringProjectMetadata && d.value.hiringProjectMetadata.name) || '';
    if (urn) return { urn, name };
  }
  return { urn: '', name: '' };
}

async function runImportProject(tab, job) {
  const csrf = await liCsrfToken();
  if (!csrf) return { ok: false, error: 'no JSESSIONID (log into LinkedIn Recruiter)' };
  const p = job.params || {};
  const baseHeaders = { 'accept': 'application/json', 'csrf-token': csrf, 'x-restli-protocol-version': '2.0.0' };
  let projectUrn = p.project_urn || '';
  let projectName = p.project_name || '';
  const projectId = String(p.project_id || (projectUrn.match(/,(\d+)\)/) || [])[1] || '').trim();
  if (!projectUrn && projectId) {
    // Build the project URN from the cached contract id + the numeric project id — the
    // pipeline-list call validates it, so no fragile project GET is needed.
    let contract = '';
    try { const s = await chrome.storage.local.get('liContract'); contract = (s && s.liContract) || ''; } catch (e) {}
    if (contract) {
      projectUrn = `urn:li:ts_hiring_project:(urn:li:ts_contract:${contract},${projectId})`;
      await log(`import: built project URN from cached contract ${contract} -> ${projectUrn}`);
    } else {
      // No cached contract yet — fall back to the (unreliable) GET, then ask the user to
      // run any Recruiter search/project first so the contract gets cached.
      await randDelay(1000, 2500);
      const rp = await resolveProjectUrn(tab, baseHeaders, projectId);
      projectUrn = rp.urn; if (!projectName) projectName = rp.name;
      await log(projectUrn ? `import: resolved project ${projectId} -> ${projectUrn}`
                           : `import: no cached contract and could not resolve project ${projectId}`);
    }
  }
  if (!projectUrn) return { ok: false, error: 'could not resolve the project — run any LinkedIn Recruiter search (or create a project) once so Scout learns your contract, then retry the import.' };
  const projectUrl = projectId ? `https://www.linkedin.com/talent/hire/${projectId}` : '';

  // Paginate the project's candidate roster (≈25/page), up to the per-run cap.
  const headers = {
    'accept': 'application/json', 'content-type': 'application/x-www-form-urlencoded',
    'csrf-token': csrf, 'x-restli-protocol-version': '2.0.0', 'x-http-method-override': 'GET',
  };
  // Request 50/page (LinkedIn's max) but advance by the ACTUAL count returned.
  const REQ = 50, CAP = LI_MAX_RESULTS;
  let candidates = [], total = 0, firstData = null, start = 0, guard = 0;
  while (candidates.length < CAP && guard++ < 30) {
    await randDelay(2500, 6000);
    const body = buildPipelineBody(projectUrn, projectName, { start, count: REQ });
    let [res] = await chrome.scripting.executeScript({
      target: { tabId: tab.id }, world: 'MAIN', func: liPageFetch, args: [LI_SEARCH_URL, headers, body] });
    let r = res && res.result;
    // Fall back to the minimal decoration if the rich one is rejected.
    if (r && r.status && (r.status < 200 || r.status >= 300) && r.status !== 401 && r.status !== 403) {
      await log(`import: page ${start} -> ${r.status}; retrying minimal decoration`);
      const body2 = buildPipelineBody(projectUrn, projectName, { start, count: REQ, minimalDecoration: true });
      [res] = await chrome.scripting.executeScript({
        target: { tabId: tab.id }, world: 'MAIN', func: liPageFetch, args: [LI_SEARCH_URL, headers, body2] });
      r = res && res.result;
    }
    if (!r || !r.ok) { if (start === 0) return { ok: false, error: `import: list failed ${r ? r.status + ' ' + (r.text || '').slice(0, 160) : 'no response'}` }; break; }
    let data; try { data = JSON.parse(r.text); } catch (e) { break; }
    if (!firstData) { firstData = data; total = (data.metadata || {}).total || 0; }
    const els = data.elements || [];
    if (!els.length) break;                            // truly no more results
    candidates = candidates.concat(parseLiElements(data, els.length));
    start += els.length;                               // advance by what we actually got
    if (total && start >= total) break;
  }
  await log(`import: project "${projectName}" — collected ${candidates.length} candidate(s)`);
  // Enrich contact/photo for the first batch we report (visiting every profile is too slow).
  await enrichLiContacts(tab, candidates.slice(0, 25));
  return { ok: true, candidates, project_url: projectUrl, total, project_name: projectName };
}

async function pollOnce() {
  const { scoutToken, scoutBase } = await getState();
  if (!scoutToken) { await log('No Scout login yet - open scout.volibits.com and sign in.'); return; }
  const base = (scoutBase || DEFAULT_BASE).replace(/\/$/, '');
  let jobs = [];
  try {
    const r = await fetch(base + '/api/naukri-agent/jobs', { headers: { 'Authorization': 'Bearer ' + scoutToken } });
    if (r.status === 401) { await log('Scout token expired - reopen scout.volibits.com.'); return; }
    if (!r.ok) { await log('Job fetch HTTP ' + r.status); return; }
    jobs = (await r.json()).jobs || [];
  } catch (e) { await log('Job fetch failed: ' + e.message); return; }
  if (!jobs.length) return;
  // Priority: run interactive search jobs (recruiter / regular LinkedIn / Naukri) BEFORE
  // background project builds, so a quick search isn't stuck behind a 100-candidate
  // create_project (which can take 2–3 min).
  const _prio = { linkedin_recruiter: 0, linkedin_regular: 0, naukri: 1, import_project: 8, create_project: 9 };
  jobs.sort((a, b) => (_prio[a.source] ?? 2) - (_prio[b.source] ?? 2));
  await log(`Got ${jobs.length} job(s) from Scout.`);

  for (const job of jobs) {
    try {
      const src = job.source || 'naukri';
      await log(`Running [${src}] "${job.query}" (id ${String(job.search_id).slice(0, 8)})`);
      let result;
      if (src === 'create_project') {
        const tab = await ensureLinkedInTab();
        if (!tab) { await postResults(job.callback_url, job.callback_token, job.search_id, [], 'no LinkedIn tab', null, src); await log('Could not open a LinkedIn tab.'); continue; }
        result = await runCreateProject(tab, job);
      } else if (src === 'import_project') {
        const tab = await ensureLinkedInTab();
        if (!tab) { await postResults(job.callback_url, job.callback_token, job.search_id, [], 'no LinkedIn tab', null, src); await log('Could not open a LinkedIn tab.'); continue; }
        result = await runImportProject(tab, job);
      } else if (src === 'linkedin_recruiter') {
        const tab = await ensureLinkedInTab();
        if (!tab) { await postResults(job.callback_url, job.callback_token, job.search_id, [], 'no LinkedIn tab', null, src); await log('Could not open a LinkedIn tab.'); continue; }
        result = await runLiJob(tab, job);
      } else if (src === 'linkedin_regular') {
        const tab = await ensureLinkedInFeedTab();
        if (!tab) { await postResults(job.callback_url, job.callback_token, job.search_id, [], 'no LinkedIn tab', null, src); await log('Could not open a LinkedIn tab.'); continue; }
        result = await runLiRegularJob(tab, job);
      } else if (!NAUKRI_ENABLED) {
        // Naukri disabled — skip the Resdex search (server shouldn't queue these anymore).
        await log(`Skipping ${src} job — Naukri sourcing is disabled.`);
        await postResults(job.callback_url, job.callback_token, job.search_id, [], 'naukri disabled', null, src);
        continue;
      } else {
        const tab = await ensureResdexTab();
        if (!tab) { await postResults(job.callback_url, job.callback_token, job.search_id, [], 'no Resdex tab', null, src); await log('Could not open a Resdex tab.'); continue; }
        result = await runJob(tab, job, await naukriCookies());
      }
      if (result.ok && result.alreadyPosted) {
        // create-project already posted its own results early (project first, then enriched).
        await log('Job done (results posted by the job itself).');
      } else if (result.ok) {
        const status = await postResults(job.callback_url, job.callback_token, job.search_id, result.candidates, null, result.project_url, src, result.project_name, result.add_blocked);
        await log(`Sent ${result.candidates.length} candidate(s)${result.project_url ? ' + project ' + result.project_url : ''} -> ${status}`);
      } else {
        await postResults(job.callback_url, job.callback_token, job.search_id, [], result.error, null, src);
        await log('Job error: ' + result.error);
      }
    } catch (e) {
      await log('Job exception: ' + e.message);
    }
  }
}

// List this user's queued/in-flight jobs (without claiming them) for the popup.
async function listScoutJobs() {
  const { scoutToken, scoutBase } = await getState();
  if (!scoutToken) return [];
  const base = (scoutBase || DEFAULT_BASE).replace(/\/$/, '');
  try {
    const r = await fetch(base + '/api/naukri-agent/queued', { headers: { 'Authorization': 'Bearer ' + scoutToken } });
    if (!r.ok) return [];
    return (await r.json()).jobs || [];
  } catch (e) { return []; }
}

// Cancel (delete) this user's queued jobs on Scout. Returns count cleared.
async function clearScoutJobs() {
  const { scoutToken, scoutBase } = await getState();
  if (!scoutToken) return 0;
  const base = (scoutBase || DEFAULT_BASE).replace(/\/$/, '');
  try {
    const r = await fetch(base + '/api/naukri-agent/clear', { method: 'POST', headers: { 'Authorization': 'Bearer ' + scoutToken } });
    if (!r.ok) return 0;
    return (await r.json()).cleared || 0;
  } catch (e) { return 0; }
}

// Auto-cancel jobs left over from a previous session so they don't silently run
// when the browser/extension restarts.
async function cancelStaleOnStartup() {
  const n = await clearScoutJobs();
  if (n) await log(`Cancelled ${n} job(s) queued in a previous session.`);
}
chrome.runtime.onStartup.addListener(cancelStaleOnStartup);
chrome.runtime.onInstalled.addListener(cancelStaleOnStartup);

chrome.alarms.onAlarm.addListener((a) => { if (a.name === POLL_ALARM) pollOnce(); });

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'start-polling') {
    chrome.alarms.create(POLL_ALARM, { periodInMinutes: 0.5 });
    setState({ polling: true });
    log('Polling started (every 30s).');
    pollOnce();
    sendResponse({ ok: true });
  } else if (msg.type === 'stop-polling') {
    chrome.alarms.clear(POLL_ALARM);
    setState({ polling: false });
    log('Polling stopped.');
    sendResponse({ ok: true });
  } else if (msg.type === 'poll-now') {
    pollOnce().then(() => sendResponse({ ok: true }));
    return true;
  } else if (msg.type === 'list-jobs') {
    listScoutJobs().then((jobs) => sendResponse({ jobs }));
    return true;
  } else if (msg.type === 'cancel-jobs') {
    clearScoutJobs().then((cleared) => { log(`Cancelled ${cleared} queued job(s).`); sendResponse({ cleared }); });
    return true;
  } else if (msg.type === 'open-dm') {
    openDmCompose(msg.url, msg.message, msg.name).then(() => sendResponse({ ok: true }));
    return true;
  }
});
