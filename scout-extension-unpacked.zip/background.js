// Service worker: stores the Scout auth, polls Scout for pending Naukri jobs,
// runs each search by calling the Resdex JSON API in the page's MAIN world
// (so it's same-origin — custom headers + cookies pass, unlike a content-script
// fetch which Resdex's CORS would strip), and posts results back to Scout.

const DEFAULT_BASE = 'https://scout.volibits.com';
const POLL_ALARM = 'scout-naukri-poll';
const ADV_SEARCH_URL =
  'https://resdex.naukri.com/cloudgateway-resdex/' +
  'recruiter-js-profile-listing-services/v0/search/results/advSearch';

async function getState() {
  return await chrome.storage.local.get(['scoutToken', 'scoutBase', 'polling', 'logs']);
}
async function setState(patch) {
  const cur = await chrome.storage.local.get(null);
  await chrome.storage.local.set({ ...cur, ...patch });
}
async function log(line) {
  const ts = new Date().toLocaleTimeString();
  const cur = await chrome.storage.local.get('logs');
  const logs = (cur.logs || []).slice(-200);
  logs.push(`${ts}  ${line}`);
  await chrome.storage.local.set({ logs });
  console.log('[scout-agent]', line);
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'scout-auth' && msg.token) {
    setState({ scoutToken: msg.token, scoutBase: msg.base || DEFAULT_BASE, scoutEmail: msg.email || '' });
    log('Scout login captured' + (msg.email ? ' (' + msg.email + ')' : ''));
  }
});

async function findResdexTab() {
  const tabs = await chrome.tabs.query({ url: 'https://resdex.naukri.com/*' });
  return tabs && tabs.length ? tabs[0] : null;
}

function waitForTabComplete(tabId, timeoutMs = 30000) {
  return new Promise(async (resolve) => {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      try {
        const t = await chrome.tabs.get(tabId);
        if (t.status === 'complete') { resolve(t); return; }
      } catch (e) { resolve(null); return; }   // tab closed
      await new Promise(r => setTimeout(r, 500));
    }
    try { resolve(await chrome.tabs.get(tabId)); } catch (e) { resolve(null); }
  });
}

// Human-like random pause before/between operations so the traffic doesn't look like
// a tight automated loop. Every network step waits a random number of seconds.
function randDelay(minMs, maxMs) {
  const ms = Math.floor(minMs + Math.random() * Math.max(0, maxMs - minMs));
  return new Promise(r => setTimeout(r, ms));
}

// Return a loaded Resdex tab. If none is open, quietly open one in the BACKGROUND
// (no focus stolen) and wait for it to finish loading, so the recruiter doesn't
// have to keep a Resdex tab open themselves.
// Return a tab that is LOADED and on the given host (so executeScript won't fail
// with "Cannot access contents of the page" on an about:blank/new-tab). Reuses an
// existing matching tab, else opens one in the background and waits for it.
function _tabOnHost(url, hostFrag) {
  return typeof url === 'string' && url.indexOf('https://') === 0 && url.indexOf(hostFrag) !== -1;
}
async function ensureTabOnHost(queryPatterns, openUrl, hostFrag, settleMs) {
  for (const q of queryPatterns) {
    const tabs = await chrome.tabs.query({ url: q });
    for (const t of tabs) {
      if (_tabOnHost(t.url, hostFrag)) {
        const ready = (t.status === 'complete') ? t : (await waitForTabComplete(t.id)) || t;
        return ready;
      }
    }
  }
  await log(`No ${hostFrag} tab open - opening one in the background...`);
  let tab = await chrome.tabs.create({ url: openUrl, active: false });
  tab = await waitForTabComplete(tab.id);
  // Verify it actually landed on the host (navigation can lag past 'complete').
  for (let i = 0; i < 8; i++) {
    tab = await chrome.tabs.get(tab.id).catch(() => null);
    if (tab && _tabOnHost(tab.url, hostFrag) && tab.status === 'complete') break;
    await new Promise(r => setTimeout(r, 1500));
  }
  if (!tab || !_tabOnHost(tab.url, hostFrag)) {
    await log(`could not load a ${hostFrag} tab (got ${tab ? tab.url : 'none'})`);
    return null;
  }
  await log(`using tab: ${tab.url}`);
  if (settleMs) await new Promise(r => setTimeout(r, settleMs));
  return tab;
}

async function ensureResdexTab() {
  return ensureTabOnHost(['https://resdex.naukri.com/*'],
    'https://resdex.naukri.com/v3?activeTab=advSrch', 'naukri.com', 2500);
}

// Read ALL naukri cookies (incl. httpOnly) for identity fields.
async function naukriCookies() {
  const map = {};
  try {
    const all = await chrome.cookies.getAll({ domain: 'naukri.com' });
    for (const c of all) map[c.name] = c.value;
  } catch (e) { /* ignore */ }
  return map;
}

function buildHeaders() {
  const txn = 'adv' + Date.now() + Math.random().toString(16).slice(2, 8) +
              '~~' + Math.random().toString(16).slice(2, 8);
  return {
    'Content-Type':     'application/json',
    'Accept':           'application/json',
    'appid':            '112',
    'systemid':         'naukriIndia',
    'x-transaction-id': txn,
  };
}

function identity(c) {
  // rdxUserId is the numeric recruiter id -> the UNCC cookie (NOT UNID, which is
  // a non-numeric token). Confirmed from the live advSearch payload.
  const rdxUserId = c.UNCC || c.resdexUserId || c.rdxUserId || c.userId || '';
  let companyId = c.UNPC || c.companyId || c.cid || '';
  for (const name in c) {
    const m = name.match(/^kycEligibleCookie(\d+)$/);
    if (m) { companyId = m[1]; break; }
  }
  const rdxUserName = c.lastLoggedInUser || c.userEmail || c.recruiterUserName || '';
  return { rdxUserId, companyId, rdxUserName };
}

const SKIP_LOCS = new Set(['india', 'in', 'bharat', 'remote', 'not specified', '']);

// Scout notice value -> Naukri notice "rank" (1=0-15d, 2=1mo, 3=2mo, 4=3mo, 5=>3mo).
// We select ALL codes <= the chosen threshold (e.g. "2 months" -> [1,2,3]), which
// matches both the captured payload and the "<= threshold" rule.
const NOTICE_RANK = { '15': 1, '30': 2, '60': 3, '90': 4, '100': 5 };
function noticeCodesFor(np) {
  if (!np) return [];
  if (String(np) === 'serving') return [1];   // currently serving ~ short notice
  const max = NOTICE_RANK[String(np)];
  if (!max) return [];
  const out = [];
  for (let c = 1; c <= max; c++) out.push(c);
  return out;
}

// Resolve city NAMES to Naukri's internal location IDs via the public taxonomy
// suggester (ACAO:* so the background can call it directly). Mirrors what the UI
// does when you type a city and pick it from the dropdown.
async function resolveLocationIds(locationStr) {
  const ids = [];
  const cities = (locationStr || '').split(/[/,|]/).map(s => s.trim()).filter(Boolean);
  for (const city of cities) {
    if (SKIP_LOCS.has(city.toLowerCase())) continue;
    try {
      const url = 'https://taxonomy-suggest.naukri.com/suggest/taxonomyCommonSuggester' +
        '?limit=15&appId=1&astext=' + encodeURIComponent(city) +
        '&resultField=id,name,type,parentTwoName&typoSupport=true&stringTypoMatch=true' +
        '&astype=city,state,country&category=location&c_query=null&p_query=null&sourceId=4001&vertical=';
      const r = await fetch(url, { credentials: 'include' });
      let t = await r.text();
      const m = t.match(/\(([\s\S]*)\)\s*;?\s*$/);   // strip JSONP wrapper if present
      if (m) t = m[1];
      const data = JSON.parse(t);
      // resultList is an object with a `title` array; each entry has name:[..], id:[..], type
      const arr = (data.resultList && Array.isArray(data.resultList.title)) ? data.resultList.title
                : Array.isArray(data.resultList) ? data.resultList
                : Array.isArray(data.results) ? data.results : [];
      const pick = v => Array.isArray(v) ? v[0] : v;
      const best = arr.find(x => (x.type || '').toLowerCase() === 'city') || arr[0];
      const idVal = best && pick(best.id);
      if (idVal != null && idVal !== '') {
        ids.push(String(idVal));
        await log(`location "${city}" -> ${idVal} (${pick(best.name) || ''})`);
      } else {
        await log(`location "${city}": no ID match`);
      }
    } catch (e) {
      await log(`location lookup failed for "${city}": ${e.message}`);
    }
  }
  return ids;
}

function buildPayload(job, cookies, locIds) {
  const p = job.params || {};
  // locIds are Naukri's internal location IDs (e.g. ["220"]), resolved from city
  // names via the taxonomy suggester. Empty => India-wide. Full advSearchParams
  // mirrors a real Resdex request so the backend doesn't 500 on missing siblings.
  const locs = locIds || [];
  const adv = {
    activeIn:                 63,
    allOrNewCV:               'ALL',
    boolKeywords:             '',
    booleanSearch:            false,
    category:                 [],
    companyType:              { search_in: ['C'] },
    currency:                 'rs',
    currentLocations:         locs,
    designation:              [],
    designationState:         'C',
    designationStrType:       'ezkw',
    disabilityTypes:          [],
    employeesExclude:         [],
    employeesExcludeState:    'C',
    employeesExcludeStrType:  'ezkw',
    employeesInclude:         [],
    employeesIncludeState:    'C',
    employeesIncludeStrType:  'ezkw',
    exDefensePersonnelTypes:  [],
    excludeIndustryIds:       [],
    ezKeywordsAll:            [{ key: '-1', value: job.query || '', type: '' }],
    ezKeywordsAny:            [],
    ezKeywordsExclude:        [],
    fareaRoleIdsEntity:       [],
    filterPreferredCompanies: false,
    gender:                   'n',
    hiringForClient:          null,
    industryIds:              [],
    jobStatusType:            '',
    jobType:                  '',
    minCtcLacs:               0,
    minCtcThsnds:             0,
    minExp:                   parseInt(p.exp_min || 0, 10) || 0,
    noticePeriod:             [],
    otherLocations:           '',
    pgCourseSpecIds:          [],
    pgEducationType:          [0],
    pgInstitutes:             [],
    pgPpgCombinationCriteria: true,
    ppgCourseSpecIds:         [],
    ppgEducationType:         [0],
    ppgInstitutes:            [],
    prefLocationChecked:      locs.length > 0,
    prefLocationCriteria:     false,
    prefLocationDd:           1,
    prefLocationExactMatch:   false,
    prefLocations:            locs,
    resPerPage:               Math.min(job.limit || 20, 100),
    searchAssistTabRequest:   false,
    searchOnZeroCtc:          true,
    selectedPgTab:            -1,
    selectedPpgTab:           -1,
    selectedUgTab:            -1,
    sortType:                 'RELEVANCE',
    srchKeywordsIn:           'ER',
    srchOnlyCvUploaded:       false,
    srchOnlyEmailVerified:    false,
    srchOnlyMobileVerified:   false,
    srchOnlyPhysicallyDisabled: false,
    srchType:                 'adv',
    stateLocations:           [],
    statePrefLocations:       [],
    swrExcludeKeywords:       [],
    swrIncludeKeywords:       [],
    swrKeywords:              '',
    topPgInstituteTags:       [],
    topPpgInstituteTags:      [],
    topUgInstituteTags:       [],
    ugCourseSpecIds:          [],
    ugEducationType:          [0],
    ugInstitutes:             [],
    ugPgCombinationCriteria:  true,
    ugPpgCombinationCriteria: false,
    womenReturningToWork:     null,
  };

  // Exclude company: keyword-based exclusion (no company-ID lookup needed).
  const _excl = (p.exclude_company || '').trim();
  if (_excl) adv.ezKeywordsExclude = [{ key: '-1', value: _excl, type: '' }];

  // Notice period: all Naukri codes <= the chosen threshold.
  adv.noticePeriod = noticeCodesFor(p.notice_period);

  const payload = { advSearchParams: adv };
  const id = identity(cookies);
  // Only include miscellaneousInfo when BOTH ids are clean integers — sending an
  // empty/non-numeric companyId or rdxUserId makes the Java backend reject the
  // body ("Illegal json format mapped"). If we can't resolve them, omit the block
  // and let the session identify the recruiter.
  const cidOk = /^\d+$/.test(String(id.companyId));
  const uidOk = /^\d+$/.test(String(id.rdxUserId));
  if (cidOk && uidOk) {
    payload.miscellaneousInfo = {
      companyId:         parseInt(id.companyId, 10),
      rdxUserId:         String(id.rdxUserId),
      rdxUserName:       id.rdxUserName,
      flowName:          'search',
      fetchClusters:     false,
      fetchResumeTuples: true,
    };
  }
  return payload;
}

const SEEKING_NOTICE = ['immediate', 'serving notice', '< 15 days', 'less than 15 days', '15 days or less'];
const SEEKING_STATUS = ['not employed', 'fresher', 'actively seeking', 'actively looking',
                        'actively applying', 'open to offers', 'open to work', 'immediate joiner'];

// Naukri Resdex shows current CTC as "₹ 32 Lacs" / "₹ 22.70 Lacs". The API field
// name is inconsistent across plans, so: 1) try common display fields, 2) build it
// from lac/thousand pairs wherever they live, 3) deep-scan for a salary-looking string.
const _SAL_RE = /(?:₹|rs\.?|inr)\s*[\d][\d.,]*\s*(?:lac|lakh|lpa|cr|crore)/i;
function extractNaukriSalary(c, eo) {
  // 0) Known advSearch structure: ctcInfo: { lacs:"32", thousands:"0", currency:"INR" }.
  const ci = c.ctcInfo || c.ctc || {};
  if (ci && typeof ci === 'object' && (ci.lacs != null || ci.thousands != null || ci.lac != null || ci.thousand != null)) {
    const li = parseInt(ci.lacs != null ? ci.lacs : (ci.lac || 0), 10);
    const ti = parseInt(ci.thousands != null ? ci.thousands : (ci.thousand || 0), 10);
    if (li || ti) return `${li}${ti ? '.' + String(ti).padStart(2, '0') : ''} Lacs`;
  }
  // 1) Direct preformatted display fields.
  for (const k of ['ctcDisplay', 'ctcText', 'salaryDisplay', 'currentCtcDisplay',
                   'ctcDetail', 'currentCtc', 'ctc', 'salary']) {
    const v = c[k];
    if (typeof v === 'string' && /\d/.test(v) && /lac|lakh|lpa|cr|₹/i.test(v)) return v.trim();
  }
  // 2) lac/thousand numeric pairs in any of the likely containers.
  const cur = (c.employment && c.employment.current) || {};
  for (const o of [c, eo || {}, cur, c.ctc || {}, c.compensation || {}]) {
    if (o && typeof o === 'object') {
      const l = o.ctcLac != null ? o.ctcLac : (o.ctcLacs != null ? o.ctcLacs : o.lac);
      const t = o.ctcThousand != null ? o.ctcThousand : (o.ctcThousands != null ? o.ctcThousands : o.thousand);
      if (l != null || t != null) {
        const li = parseInt(l || 0, 10), ti = parseInt(t || 0, 10);
        if (li || ti) return `${li}${ti ? '.' + String(ti).padStart(2, '0') : ''} Lacs`;
      }
    }
  }
  // 3) Deep KEY-based scan (depth<=3). The advSearch API returns CTC as numbers under
  //    a field whose name contains "ctc"/"salary" — match by key name, not value shape.
  let found = '';
  const seen = new Set();
  const fmtLac = (lac, thou) => `${parseInt(lac || 0, 10)}${thou ? '.' + String(parseInt(thou, 10)).padStart(2, '0') : ''} Lacs`;
  const numToSalary = (v) => v >= 100000 ? `${Math.round(v / 10000) / 10} LPA` : `${v} LPA`; // rupees vs lakhs
  (function walk(o, depth) {
    if (found || o == null || depth > 3 || typeof o !== 'object' || seen.has(o)) return;
    seen.add(o);
    // lac/thousand pair at this level (any naming).
    const lac = o.ctcLac != null ? o.ctcLac : (o.ctcLacs != null ? o.ctcLacs : (o.lac != null ? o.lac : o.lacs));
    const thou = o.ctcThousand != null ? o.ctcThousand : (o.ctcThousands != null ? o.ctcThousands : (o.thousand != null ? o.thousand : o.thousands));
    if ((lac != null && lac !== '') || (thou != null && thou !== '')) {
      const li = parseInt(lac || 0, 10), ti = parseInt(thou || 0, 10);
      if (li || ti) { found = fmtLac(li, ti); return; }
    }
    for (const k of Object.keys(o)) {
      if (found) break;
      const v = o[k];
      if (/ctc|salary/i.test(k)) {
        if (typeof v === 'string' && /\d/.test(v)) { found = v.trim(); break; }
        if (typeof v === 'number' && v > 0) { found = numToSalary(v); break; }
        if (v && typeof v === 'object') { walk(v, depth + 1); if (found) break; }
      }
      if (v && typeof v === 'object') walk(v, depth + 1);
    }
  })(c, 0);
  return found;
}

function mapTuple(c, fallbackTitle) {
  const name = c.jsUserName || c.name || c.fullName || 'Unknown';
  const empCur = (c.employment && c.employment.current) || {};
  const role = empCur.designation || c.jobTitle || c.designation || fallbackTitle || '';
  const company = empCur.organization || c.currentEmployer || c.company || '';
  let exp = '', expYears = null;
  const eo = c.experience || {};
  if (eo && typeof eo === 'object' && eo.years != null) {
    const y = parseInt(eo.years, 10), mo = parseInt(eo.months || 0, 10);
    exp = mo ? `${y}y ${mo}m` : `${y}y`;
    expYears = Math.round((y + mo / 12) * 10) / 10;
  }
  const skillsRaw = c.keySkills || c.focusedSkills || '';
  const skills = Array.isArray(skillsRaw) ? skillsRaw.slice(0, 8)
    : (skillsRaw ? skillsRaw.split(',').map(s => s.trim()).filter(Boolean).slice(0, 8) : []);
  const npLabel = c.noticePeriodLabel || '';
  const npRaw = c.noticePeriod || '';
  const notice = String(npLabel).trim() || (/^\d+$/.test(String(npRaw)) ? '' : String(npRaw).trim());
  const tags = c.profileTags || [];
  let activity = '';
  for (const t of tags) { if (t && t.label) { activity = t.label; break; } }
  const immediate = !!(c.immediateAvailabilty || c.immediateAvailability);
  const nl = notice.toLowerCase(), al = activity.toLowerCase();
  const otw = immediate || SEEKING_NOTICE.some(v => nl.includes(v)) || SEEKING_STATUS.some(v => al.includes(v));
  const uid = c.uniqueId || c.profileId || c.id || '';
  // Contact info — present in the Resdex listing when the recruiter's plan exposes it.
  const email = c.email || c.emailId || c.emailAddress || c.email_id || '';
  const phoneRaw = c.phoneNumber || c.mobile || c.phone || c.mobileNumber || c.contactNumber || '';
  const phone = phoneRaw ? String(phoneRaw).trim() : '';
  // Current salary / CTC. Naukri's listing shows it as e.g. "₹ 32 Lacs" / "₹ 22.70 Lacs"
  // but the API field name varies, so extract robustly instead of guessing one key.
  const salary = extractNaukriSalary(c, eo);
  // Expected salary: expectedCtcLacs/expectedCtcThousands (strings like "35.0").
  let expectedSalary = '';
  {
    const l = parseInt(parseFloat(c.expectedCtcLacs || 0), 10);
    const t = parseInt(parseFloat(c.expectedCtcThousands || 0), 10);
    if (l || t) expectedSalary = `${l}${t ? '.' + String(t).padStart(2, '0') : ''} Lacs`;
  }
  // Preferred work locations (comma-separated string).
  const prefLocations = (typeof c.preferredLocations === 'string' && c.preferredLocations) ? c.preferredLocations.trim() : '';
  // "Active today" / "Active 3 days ago" etc.
  const activeLabel = (c.activeDateLabel || activity || '').trim();
  const emp = c.employment || {};
  const edu = c.education || {};
  return {
    name, role, company, email: String(email).trim(), phone, salary,
    expected_salary: expectedSalary,
    location: (typeof c.currentLocation === 'string' && c.currentLocation) || '',
    pref_locations: prefLocations,
    linkedin: '', naukri: uid ? `https://resdex.naukri.com/recruiter-profile/${uid}` : '',
    skills, experience: exp, exp_years: expYears, notice, notice_period: notice,
    activity, active_label: activeLabel,
    cv_available: !!(c.cvAttached || c.cvPreviewRedirectionUrl),
    headline: (c.resumeHeadline || c.profileTitle || c.summary || '').trim(),
    tags: [], source: 'naukri-resdex', open_to_work: otw,
    // ── Full detail set (for the candidates DB table) ──────────────────────
    details: {
      unique_id: uid,
      js_user_id: c.jsUserId || null,
      js_res_id: c.jsResId || null,
      photo_id_hash: c.photoIdHash || c.thumbnailPhotoIdHash || '',
      photo_url: '',                                  // built once we know Naukri's CDN format
      skills_all: skillsRaw && typeof skillsRaw === 'string' ? skillsRaw : (Array.isArray(skillsRaw) ? skillsRaw.join(', ') : ''),
      focused_skills: c.focusedSkills || '',
      current_designation: (emp.current || {}).designation || '',
      current_company: (emp.current || {}).organization || '',
      current_start: (emp.current || {}).startDate || '',
      previous_designation: (emp.previous || {}).designation || '',
      previous_company: (emp.previous || {}).organization || '',
      employment_history: c.historicalEmployment || [],
      education_ug: edu.ug || null,
      education_pg: edu.pg || null,
      education_ppg: edu.ppg || null,
      ctc_current: salary,
      ctc_expected: expectedSalary,
      ctc_fixed_lacs: c.fixedCtcLacs || null,
      ctc_variable_lacs: c.variableCtcLacs || null,
      salary_disclosed: !!c.salaryDisclosed,
      preferred_locations: prefLocations,
      notice_period_label: c.noticePeriodLabel || '',
      notice_period_code: c.noticePeriod != null ? c.noticePeriod : null,
      certifications: c.certifications || null,
      email_verified: !!c.emailVerified,
      mobile_verified: !!c.mobileNumberPresent,
      cv_attached: !!c.cvAttached,
      num_views: c.numberOfViews || 0,
      num_downloads: c.numberOfDownloads || 0,
      active_date_millis: c.activeDateMillis || null,
      modify_date_millis: c.modifyDateMillis || null,
      fresher: !!c.fresher,
      premium: !!(c.premiumCandidate || c.premiumTalent),
    },
    raw: c,                                            // full tuple — nothing lost
  };
}

// Runs in the PAGE's MAIN world (same-origin) so custom headers + cookies work.
function pageFetch(url, headers, body) {
  return fetch(url, { method: 'POST', credentials: 'include', headers, body: JSON.stringify(body) })
    .then(r => r.text().then(t => ({ status: r.status, ok: r.ok, text: t })))
    .catch(e => ({ status: 0, ok: false, text: String(e) }));
}

async function callResdex(tabId, payload) {
  const [res] = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func: pageFetch,
    args: [ADV_SEARCH_URL, buildHeaders(), payload],
  });
  return res && res.result;
}

async function postResults(callbackUrl, callbackToken, searchId, candidates, error, projectUrl, source) {
  const body = { search_id: searchId, candidates: candidates || [], error: error || null };
  if (projectUrl) body.project_url = projectUrl;
  if (source) body.source = source;
  const res = await fetch(callbackUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + callbackToken },
    body: JSON.stringify(body),
  });
  return res.status;
}

async function runJob(tab, job, cookies) {
  const _id = identity(cookies);
  await log(`identity: rdxUserId=${_id.rdxUserId || '(none)'} companyId=${_id.companyId || '(none)'}`);
  const locIds = await resolveLocationIds((job.params || {}).location);
  const payload = buildPayload(job, cookies, locIds);
  await randDelay(2000, 5000);                       // human-like pause before searching
  const r = await callResdex(tab.id, payload);
  if (!r) return { ok: false, error: 'no response from page fetch' };
  if (r.status === 401 || r.status === 403) return { ok: false, error: `Resdex ${r.status}: ${(r.text || '').slice(0, 250)}` };
  if (!r.ok) return { ok: false, error: `Resdex API HTTP ${r.status}: ${(r.text || '').slice(0, 200)}` };
  let data;
  try { data = JSON.parse(r.text); } catch (e) { return { ok: false, error: 'bad JSON from Resdex' }; }
  const raw = data.tuples || data.profileList || data.candidates || data.results || [];
  // One-time diagnostic: log the first profile's structure so we can pin the real
  // CTC / profile-id field names. Dump ALL top-level key names, plus the values of
  // any key that looks money- or id-related.
  if (raw[0]) {
    const c0 = raw[0];
    await log(`naukri ALL keys: ${Object.keys(c0).join(',').slice(0, 700)}`);
    const interesting = Object.keys(c0).filter(k => /id|url|link|profile|resume|username|encrypt|ctc|salary|sal|lac|comp|pay|employ/i.test(k));
    const dump = interesting.map(k => `${k}=${JSON.stringify(c0[k]).slice(0, 80)}`).join(' | ');
    await log(`naukri profile fields: ${dump.slice(0, 800)}`);
  }
  const candidates = raw.slice(0, job.limit || 20).map(c => mapTuple(c, job.query));
  return { ok: true, candidates, total: data.totalResumes };
}

// ── LinkedIn Recruiter (talentRecruiterSearchHits) ──────────────────────────
const LI_SEARCH_URL = 'https://www.linkedin.com/talent/search/api/talentRecruiterSearchHits';

// Field projection (subset of the real decoration). LinkedIn expects ( ) , as
// %28 %29 %2C ; ~ and * stay literal.
const LI_DECORATION_RAW =
  '(entityUrn,linkedInMemberProfileUrn~(entityUrn,firstName,lastName,unobfuscatedFirstName,' +
  'unobfuscatedLastName,headline,industryName,location(displayName),publicProfileUrl,networkDistance,' +
  'memberPreferences(openToNewOpportunities),currentPositions*(companyName,title,startDateOn,location(displayName))))';
function liEncDecoration(s) { return s.replace(/\(/g, '%28').replace(/\)/g, '%29').replace(/,/g, '%2C'); }

// Encode a RestLi text VALUE (space->%20, comma->%2C, parens, colon, etc.)
function liEncVal(s) {
  return encodeURIComponent(String(s)).replace(/[()'!*~]/g, c => '%' + c.charCodeAt(0).toString(16).toUpperCase());
}

// LinkedIn notice-period segment values (attr 224001), ascending by days.
const LI_NOTICE = [
  { days: 0,    id: '1620001', label: 'Immediately available' },
  { days: 15,   id: '248001',  label: '15 days or less' },
  { days: 30,   id: '249001',  label: '30 days' },
  { days: 45,   id: '1619001', label: '45 days' },
  { days: 60,   id: '250001',  label: '60 days' },
  { days: 90,   id: '250002',  label: '90 days' },
  { days: 9999, id: '249002',  label: 'More than 90 days' },
];
// LinkedIn expected-salary segment values (attr 1505001), ascending by lakhs.
const LI_SALARY = [
  { lakhs: 1,   id: '1616001', label: '₹ 1+ Lakhs' },
  { lakhs: 3,   id: '1617001', label: '₹ 3+ Lakhs' },
  { lakhs: 6,   id: '1618001', label: '₹ 6+ Lakhs' },
  { lakhs: 10,  id: '1618002', label: '₹ 10+ Lakhs' },
  { lakhs: 15,  id: '251001',  label: '₹ 15+ Lakhs' },
  { lakhs: 25,  id: '251002',  label: '₹ 25+ Lakhs' },
  { lakhs: 40,  id: '252001',  label: '₹ 40+ Lakhs' },
  { lakhs: 60,  id: '252002',  label: '₹ 60+ Lakhs' },
  { lakhs: 75,  id: '253001',  label: '₹ 75+ Lakhs' },
  { lakhs: 100, id: '251003',  label: '₹ 1+ Cr' },
];
function liNoticeValues(np) {
  if (!np) return [];
  let t;
  if (String(np) === '100') t = 9999;        // "more than 3 months" -> all
  else if (String(np) === 'serving') t = 15; // serving notice ~ short
  else t = parseInt(np, 10) || 0;
  return LI_NOTICE.filter(n => n.days <= t);
}
function liSalaryValues(maxBudget) {
  const b = parseFloat(maxBudget);
  if (!b) return [];
  return LI_SALARY.filter(s => s.lakhs <= b);
}
function liSegAttr(attrId, vals) {
  const vlist = vals.map(v =>
    `(displayValue:${liEncVal(v.label)},negated:false,` +
    `attributeValueV2Urn:${liEncVal('urn:li:ts_segment_attribute_value_v2:' + v.id)},` +
    `selected:true,required:false)`).join(',');
  return `(attributeV2Urn:${liEncVal('urn:li:ts_segment_attribute_v2:' + attrId)},` +
         `attributeValues:List(${vlist}))`;
}

function buildLiBody(job, geo, company, opts) {
  const p = job.params || {};
  const title = job.query || p.title || '';
  const skills = (p.skills || []).slice(0, 8);
  const expMin = parseInt(p.exp_min || 0, 10) || 0;
  // OTW (TALENT_POOL isInterestedCandidate:true) facet. For a normal recruiter search
  // it's ON by default (surface interested candidates). For create-project we want to
  // SAVE every fetched profile regardless of open-to-work, so default it OFF there
  // (still honored if the caller explicitly passes open_to_work:true).
  const otw = job.source === 'create_project'
    ? (p.open_to_work === true)
    : (p.open_to_work !== false);
  const parts = ['capSearchSortBy:RELEVANCE'];
  // Titles: use the analysis's matching-title list if provided, else the single title.
  const titlesArr = (Array.isArray(p.titles) && p.titles.length) ? p.titles.slice(0, 5) : [title];
  const titleItems = titlesArr.filter(Boolean)
    .map(t => `(text:${liEncVal(t)},negated:false,required:false)`);
  parts.push(`titles:List(${titleItems.join(',')})`);
  // Qualifications (semanticCriteriaDetails) = experience + JD-derived criteria phrases.
  const sem = [];
  if (expMin > 0) sem.push(`(qualifier:PREFERRED,text:${liEncVal(expMin + '+ years of experience')})`);
  for (const c of (p.criteria || []).slice(0, 8)) sem.push(`(qualifier:PREFERRED,text:${liEncVal(c)})`);
  if (sem.length) parts.push(`semanticCriteriaDetails:List(${sem.join(',')})`);
  // Skills -> structured skills:List. LinkedIn's required:true means a candidate must
  // have ALL of them (narrow, can collapse to zero). Default = PREFERRED (broad, ranks
  // by match). When the user toggles "require must-have skills" on, gate with required:true.
  // create_project always stays preferred (it needs a broad pool to pick the top N from).
  const requireSkills = p.require_skills === true && job.source !== 'create_project';
  const mustHave = skills;                          // p.skills (primary / must-have)
  const canHave  = (p.pref_skills || []).slice(0, 8); // good-to-have
  const skillItems = [];
  for (const s of mustHave) skillItems.push(`(text:${liEncVal(s)},negated:false,required:${requireSkills ? 'true' : 'false'},displayValue:${liEncVal(s)})`);
  for (const s of canHave)  skillItems.push(`(text:${liEncVal(s)},negated:false,required:false,displayValue:${liEncVal(s)})`);
  if (skillItems.length) {
    parts.push(`skills:List(${skillItems.join(',')})`);
    parts.push('skillScope:ALL_PROFILE_SKILLS');
  }
  // Exclude company: top-level companies:List (negated) + companyScope (not a facet).
  if (company && company.id) {
    parts.push(`companies:List((text:${liEncVal(company.name || '')},` +
      `entity:${liEncVal('urn:li:ts_company:' + company.id)},negated:true,required:false,` +
      `selected:true,scope:(timeScope:CURRENT_OR_PAST)))`);
    parts.push('companyScope:CURRENT_OR_PAST');
  }
  const facets = [], facetSel = [];
  if (geo && geo.id) {
    facets.push('BING_GEO_SWR');
    facetSel.push(`(type:BING_GEO_SWR,valuesWithSelections:List((value:${liEncVal(geo.id)},` +
      `displayValue:${liEncVal(geo.displayName || '')},negated:false,required:false)))`);
  }
  if (otw) {
    facets.push('TALENT_POOL');
    facetSel.push('(type:TALENT_POOL,valuesWithSelections:List((value:' +
      liEncVal('isInterestedCandidate:true') + ',negated:false,required:false)))');
  }
  // Notice period + expected salary (max budget) via segment attributes.
  const segAttrs = [];
  const npVals = liNoticeValues(p.notice_period);
  if (npVals.length) segAttrs.push(liSegAttr('224001', npVals));
  const salVals = liSalaryValues(p.salary_max);
  if (salVals.length) segAttrs.push(liSegAttr('1505001', salVals));
  if (segAttrs.length) {
    facets.push('SEGMENT_ATTRIBUTE_AND_VALUES');
    parts.push(`segmentAttributes:List(${segAttrs.join(',')})`);
  }
  if (facets.length) {
    parts.push(`facets:List(${facets.join(',')})`);
    parts.push(`facetSelections:List(${facetSel.join(',')})`);
  }
  const query = `(${parts.join(',')})`;
  const requestParams = '(doFacetCounting:true,doFacetDecoration:true,uiOrigin:GLOBAL_SEARCH_HEADER)';
  // opts.{start,count} let create-project paginate (LinkedIn returns ~25/page).
  const count = (opts && opts.count) || Math.min(job.limit || 25, 50);
  const start = (opts && opts.start) || 0;
  return `decoration=${liEncDecoration(LI_DECORATION_RAW)}&count=${count}&q=recruiterSearch` +
         `&query=${query}&requestParams=${requestParams}&start=${start}`;
}

// MAIN-world fetch for LinkedIn (POST + x-http-method-override:GET, form body).
function liPageFetch(url, headers, body) {
  return fetch(url, { method: 'POST', credentials: 'include', headers, body })
    .then(r => r.text().then(t => ({ status: r.status, ok: r.ok, text: t })))
    .catch(e => ({ status: 0, ok: false, text: String(e) }));
}

async function liCsrfToken() {
  try {
    const c = await chrome.cookies.get({ url: 'https://www.linkedin.com', name: 'JSESSIONID' });
    return c ? c.value.replace(/^"|"$/g, '') : '';   // strip surrounding quotes
  } catch (e) { return ''; }
}

// MAIN-world GET (same-origin) for LinkedIn typeahead etc.
function liPageGet(url, headers) {
  return fetch(url, { method: 'GET', credentials: 'include', headers })
    .then(r => r.text().then(t => ({ status: r.status, ok: r.ok, text: t })))
    .catch(e => ({ status: 0, ok: false, text: String(e) }));
}

// Resolve a city NAME to LinkedIn's geo ID via the talentTypeaheads endpoint
// (run in MAIN world; same-origin so cookies + csrf header work).
async function resolveLiGeo(tabId, city, csrf) {
  if (!city) return null;
  const url = 'https://www.linkedin.com/talent/api/talentTypeaheads?q=geo&query=' +
              encodeURIComponent(city) + '&useCase=RECRUITER_SEARCH';
  const headers = { 'accept': 'application/json', 'csrf-token': csrf, 'x-restli-protocol-version': '2.0.0' };
  let res;
  try {
    [res] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: liPageGet, args: [url, headers] });
  } catch (e) { return null; }
  const r = res && res.result;
  if (!r || !r.ok) return null;
  let data; try { data = JSON.parse(r.text); } catch (e) { return null; }
  const els = data.elements || [];
  const geoOf = e => (e.hitInfoUnion && e.hitInfoUnion.typeaheadBingGeoLocation) || {};
  const cl = city.toLowerCase();
  // Prefer an India match that starts with the typed city, else any starts-with, else first.
  const pick = els.find(e => { const g = geoOf(e); return g.countryCode === 'IN' && (g.displayName || '').toLowerCase().startsWith(cl); })
            || els.find(e => { const g = geoOf(e); return (g.displayName || '').toLowerCase().startsWith(cl); })
            || els[0];
  if (!pick) return null;
  const g = geoOf(pick);
  const id = String(g.geoUrn || g.entityUrn || '').split(':').pop();
  return id ? { id, displayName: g.displayName || city } : null;
}

// Resolve a company NAME to its ts_company id via talentTypeaheads (MAIN world).
async function resolveLiCompany(tabId, name, csrf) {
  if (!name) return null;
  const url = 'https://www.linkedin.com/talent/api/talentTypeaheads?q=company&query=' + encodeURIComponent(name);
  const headers = { 'accept': 'application/json', 'csrf-token': csrf, 'x-restli-protocol-version': '2.0.0' };
  let res;
  try { [res] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: liPageGet, args: [url, headers] }); }
  catch (e) { return null; }
  const r = res && res.result;
  if (!r || !r.ok) return null;
  let data; try { data = JSON.parse(r.text); } catch (e) { return null; }
  const els = data.elements || [];
  const nl = name.toLowerCase();
  const txt = e => ((e.text && e.text.text) || '').toLowerCase();
  const pick = els.find(e => txt(e) === nl) || els.find(e => txt(e).includes(nl)) || els[0];
  if (!pick) return null;
  const co = (pick.hitInfoUnion && pick.hitInfoUnion.typeaheadCompany) || {};
  const id = String(co.company || co.entityUrn || '').split(':').pop();
  return id ? { id, name: (pick.text && pick.text.text) || name } : null;
}

function parseLiElements(data, limit) {
  const els = data.elements || data.results || [];
  const out = [];
  for (const e of els.slice(0, limit || 25)) {
    const pr = e.linkedInMemberProfileUrnResolutionResult || e.linkedInMemberProfileUrn || {};
    const name = ((pr.unobfuscatedFirstName || pr.firstName || '') + ' ' +
                  (pr.unobfuscatedLastName || pr.lastName || '')).trim() || 'LinkedIn member';
    const cp = (pr.currentPositions || [])[0] || {};
    const mp = pr.memberPreferences || {};
    // Build the in-Recruiter profile link from the ts_profile id (open inside
    // LinkedIn Recruiter, not the public /in/ page).
    let tsId = '';
    const ref = pr.referenceUrn || '';
    if (ref.indexOf('urn:li:ts_profile:') === 0) tsId = ref.split(':').pop();
    if (!tsId && pr.entityUrn) {
      const m = pr.entityUrn.match(/ts_profile:([A-Za-z0-9_-]+)/);
      if (m) tsId = m[1];
    }
    const recruiterUrl = tsId
      ? `https://www.linkedin.com/talent/profile/${tsId}`
      : (pr.publicProfileUrl || '');
    // Contact info — only present if LinkedIn returns it (usually requires unlock).
    const ci = pr.contactInfo || pr.contactInformation || {};
    const liEmail = pr.emailAddress || ci.emailAddress ||
      ((ci.emailAddresses || [])[0] && ((ci.emailAddresses[0].emailAddress) || ci.emailAddresses[0])) || '';
    const liPhone = pr.phoneNumber ||
      ((ci.phoneNumbers || [])[0] && ((ci.phoneNumbers[0].number) || (ci.phoneNumbers[0].phoneNumber) || ci.phoneNumbers[0])) || '';
    // Expected salary if the profile exposes a compensation preference.
    const liSalary = (mp.salary && (mp.salary.displayValue || mp.salary.amount)) ||
      pr.expectedSalary || pr.compensation || '';
    const positions = pr.currentPositions || [];
    out.push({
      name,
      role: cp.title || (pr.headline || '').split(/ at | \| /)[0] || '',
      company: cp.companyName || '',
      email: String(liEmail || '').trim(), phone: String(liPhone || '').trim(),
      salary: String(liSalary || '').trim(),
      location: (pr.location && pr.location.displayName) || '',
      linkedin: recruiterUrl,
      public_url: pr.publicProfileUrl || '',
      headline: pr.headline || '',
      skills: [], tags: [],
      source: 'linkedin-recruiter',
      open_to_work: !!mp.openToNewOpportunities,
      photo_url: '', cv_available: false,
      // ── Full detail set (for the candidates DB table) ──────────────────────
      details: {
        ts_profile_id: tsId || '',
        public_url: pr.publicProfileUrl || '',
        industry: pr.industryName || '',
        network_distance: pr.networkDistance || '',
        current_title: cp.title || '',
        current_company: cp.companyName || '',
        current_start: cp.startDateOn || cp.startDate || null,
        positions: positions.map(p => ({
          title: p.title || '', company: p.companyName || '',
          start: p.startDateOn || p.startDate || null,
          location: (p.location && p.location.displayName) || '',
        })),
        open_to_work: !!mp.openToNewOpportunities,
        photo_url: '', resume_url: '',
      },
      raw: e,                                            // full search-hit record
    });
  }
  return out;
}

// Runs in the profile page's MAIN world. Scrapes email + phone from the rendered
// LinkedIn Recruiter profile (search hits never contain contact info). Mirrors the
// old git-actions scraper: data-anonymize attrs, mailto:, then a text-node walk.
function scrapeLiContactDom() {
  const emailRe = /^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$/;
  const phoneRe = /^\+?[0-9][0-9 \-]{8,14}[0-9]$/;
  let email = '';
  const anEl = document.querySelector('[data-anonymize="email"]');
  if (anEl) email = (anEl.innerText || anEl.textContent || '').trim();
  if (!email) { const ml = document.querySelector('a[href^="mailto:"]'); if (ml) email = ml.href.replace('mailto:', '').split('?')[0].trim(); }
  if (!email) { const ei = document.querySelector('input[type="email"]'); if (ei && ei.value) email = ei.value.trim(); }
  if (!email) {
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    let n; while ((n = w.nextNode())) { const t = n.textContent.trim(); if (emailRe.test(t) && !t.toLowerCase().includes('linkedin')) { email = t; break; } }
  }
  if (!email) { const m = (document.body.innerText || '').slice(0, 3000).match(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/); if (m && !/linkedin|naukri/i.test(m[0])) email = m[0]; }
  let phone = '';
  const anPhone = document.querySelector('[data-anonymize="phone"],[data-anonymize="phone-number"]');
  if (anPhone) phone = (anPhone.innerText || anPhone.textContent || '').replace(/\s*\(.*?\)\s*/g, ' ').trim();
  if (!phone) {
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    let n; while ((n = w.nextNode())) { const t = n.textContent.replace(/\s*\(.*?\)\s*/g, ' ').trim(); if (phoneRe.test(t)) { phone = t; break; } }
  }

  // Open-to-work preferences (Notice period + preferred Locations). Find the value
  // that sits next to a label in the rendered profile. Try a DOM-label lookup first,
  // then fall back to a regex over the section's innerText.
  function valueForLabel(label) {
    const els = Array.from(document.querySelectorAll('h3,h4,dt,span,div,p,strong'));
    const lab = els.find(e => (e.innerText || e.textContent || '').trim().toLowerCase() === label.toLowerCase());
    if (!lab) return '';
    // value is usually the next sibling, or the next element in the parent.
    let v = lab.nextElementSibling;
    if (!v && lab.parentElement) v = lab.parentElement.nextElementSibling;
    const txt = v && (v.innerText || v.textContent || '').trim();
    return txt || '';
  }
  let notice = valueForLabel('Notice period');
  let jobType = valueForLabel('Job type');
  let locations = '';
  // Preferred locations: collect the lines under the "Locations" label (On-site / Remote).
  const locLab = Array.from(document.querySelectorAll('h3,h4,dt,span,div,p,strong'))
    .find(e => (e.innerText || e.textContent || '').trim().toLowerCase() === 'locations');
  if (locLab) {
    let v = locLab.nextElementSibling || (locLab.parentElement && locLab.parentElement.nextElementSibling);
    if (v) locations = (v.innerText || v.textContent || '').replace(/\s*\n\s*/g, ' ').trim();
  }
  // Regex fallback over visible text.
  const body = (document.body.innerText || '');
  if (!notice) { const m = body.match(/Notice period\s*\n\s*([^\n]+)/i); if (m) notice = m[1].trim(); }
  if (!jobType) { const m = body.match(/Job type\s*\n\s*([^\n]+)/i); if (m) jobType = m[1].trim(); }
  if (!locations) {
    const m = body.match(/Locations\s*\n([\s\S]{0,300}?)(?:\n\s*Workplace types|\n\s*Experience|\n\n)/i);
    if (m) locations = m[1].replace(/\s*\n\s*/g, ' ').trim();
  }
  // Trim a too-long location blob to keep cards tidy.
  if (locations.length > 200) locations = locations.slice(0, 200).trim() + '…';

  // Profile photo (avatar). LinkedIn Recruiter tags it data-anonymize="headshot-photo";
  // fall back to any licdn profile image.
  let photo = '';
  const ph = document.querySelector('img[data-anonymize="headshot-photo"]');
  if (ph && ph.src) photo = ph.src;
  if (!photo) {
    const imgs = Array.from(document.querySelectorAll('img'));
    const cand = imgs.find(im => /media\.licdn|dms\/image|profile-displayphoto|profile-photo/i.test(im.src || ''));
    if (cand) photo = cand.src;
  }
  // Attached resume / CV link, if the profile has one.
  let resume = '';
  const a = Array.from(document.querySelectorAll('a[href]'))
    .find(el => /attachment|ambry|dms-uploads|\.pdf($|\?)|\.docx?($|\?)/i.test(el.href || ''));
  if (a) resume = a.href;

  return { email, phone, notice, jobType, locations, photo, resume };
}

// Visit each candidate's Recruiter profile and scrape email/phone (as the old
// GitHub-actions runner did). Navigates the SAME tab in the background.
async function enrichLiContacts(tab, candidates) {
  let got = 0;
  for (const c of candidates) {
    const url = c.linkedin || '';
    if (url.indexOf('/talent/profile/') === -1) continue;
    try {
      await randDelay(2500, 6000);                    // human-like gap between profile opens
      await chrome.tabs.update(tab.id, { url });
      await waitForTabComplete(tab.id);
      await randDelay(2000, 4500);                    // let contact info render + look human
      const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: scrapeLiContactDom });
      const d = r && r.result;
      if (d) {
        if (d.email) c.email = d.email;
        if (d.phone) c.phone = d.phone;
        if (d.notice) c.notice_period = d.notice;
        if (d.jobType) c.job_type = d.jobType;
        if (d.locations) c.pref_locations = d.locations;
        if (d.photo) { c.photo_url = d.photo; if (c.details) c.details.photo_url = d.photo; }
        if (d.resume) { c.resume_url = d.resume; c.cv_available = true; if (c.details) c.details.resume_url = d.resume; }
        if (d.email || d.phone) got++;
      }
    } catch (e) { /* skip this profile */ }
  }
  await log(`LinkedIn: enriched contact info for ${got}/${candidates.length}`);
  return candidates;
}

async function ensureLinkedInTab() {
  return ensureTabOnHost(['https://www.linkedin.com/talent/*', 'https://www.linkedin.com/*'],
    'https://www.linkedin.com/talent/', 'www.linkedin.com', 2500);
}

// Regular LinkedIn (Voyager) doesn't need Recruiter — use any logged-in www.linkedin.com
// tab, opening the feed (loads for every account, unlike /talent which needs a seat).
async function ensureLinkedInFeedTab() {
  return ensureTabOnHost(['https://www.linkedin.com/*'],
    'https://www.linkedin.com/feed/', 'www.linkedin.com', 2500);
}

// Resolve the per-search context (csrf + geo + exclude-company) ONCE so we can
// reuse it across paginated page fetches without re-running the typeaheads.
async function liSearchContext(tab, job) {
  const csrf = await liCsrfToken();
  if (!csrf) return { ok: false, error: 'no JSESSIONID (log into LinkedIn Recruiter)' };
  let geo = null;
  const loc = String((job.params || {}).location || '').trim();
  if (loc && loc.toLowerCase() !== 'not specified') {
    await randDelay(800, 2000);
    geo = await resolveLiGeo(tab.id, loc.split(/[/,|]/)[0].trim(), csrf);
    await log(geo ? `LinkedIn location "${loc}" -> ${geo.id} (${geo.displayName})`
                  : `LinkedIn location "${loc}": no geo match (searching nationwide)`);
  }
  let company = null;
  const excl = String((job.params || {}).exclude_company || '').trim();
  if (excl) {
    await randDelay(800, 2000);
    company = await resolveLiCompany(tab.id, excl, csrf);
    await log(company ? `LinkedIn exclude "${excl}" -> ${company.id} (${company.name})`
                      : `LinkedIn exclude "${excl}": no company match`);
  }
  return { ok: true, csrf, geo, company };
}

// Fetch ONE page of a recruiter search using a resolved context. start/count paginate.
async function liSearchPage(tab, job, ctx, start, count) {
  const headers = {
    'accept': 'application/json',
    'content-type': 'application/x-www-form-urlencoded',
    'csrf-token': ctx.csrf,
    'x-restli-protocol-version': '2.0.0',
    'x-http-method-override': 'GET',
  };
  const liBody = buildLiBody(job, ctx.geo, ctx.company, { start, count });
  await randDelay(2500, 6000);                       // human-like pause before each page
  const [res] = await chrome.scripting.executeScript({
    target: { tabId: tab.id }, world: 'MAIN', func: liPageFetch,
    args: [LI_SEARCH_URL, headers, liBody],
  });
  const r = res && res.result;
  if (!r) return { ok: false, error: 'no response from page fetch' };
  // Diagnostic: on any non-2xx, log the query string we sent (e.g. 422 = bad query).
  if (r.status && (r.status < 200 || r.status >= 300)) {
    const qm = /query=([^&]*)/.exec(liBody);
    await log(`LinkedIn search ${r.status}; query=${decodeURIComponent(qm ? qm[1] : liBody).slice(0, 600)}`);
  }
  if (r.status === 401 || r.status === 403) return { ok: false, error: `LinkedIn ${r.status} (re-login in Recruiter)` };
  // 307 = no active full-Recruiter contract for this session.
  if (r.status === 307) return { ok: false, error: 'LinkedIn Recruiter session not active — open linkedin.com/talent, let it fully load (run one search manually), then retry. If you only have Recruiter Lite (no full Recruiter seat), recruiter search isn\'t available.' };
  if (!r.ok) return { ok: false, error: `LinkedIn API HTTP ${r.status}: ${(r.text || '').slice(0, 200)}` };
  let data; try { data = JSON.parse(r.text); } catch (e) { return { ok: false, error: 'bad JSON from LinkedIn' }; }
  return { ok: true, data };
}

// Run the LinkedIn Recruiter search (single page); returns { ok, data, geo, csrf, company }.
async function liRunSearch(tab, job) {
  const ctx = await liSearchContext(tab, job);
  if (!ctx.ok) return ctx;
  const p = await liSearchPage(tab, job, ctx, 0, Math.min(job.limit || 25, 50));
  if (!p.ok) return p;
  return { ok: true, data: p.data, geo: ctx.geo, csrf: ctx.csrf, company: ctx.company };
}

async function runLiJob(tab, job) {
  const s = await liRunSearch(tab, job);
  if (!s.ok) return s;
  const candidates = parseLiElements(s.data, job.limit || 25);
  // Visit each profile to scrape email/phone (search hits don't include them).
  await enrichLiContacts(tab, candidates);
  return { ok: true, candidates, total: (s.data.metadata || {}).total };
}

// ── Regular LinkedIn (Voyager people search) — runs in the user's own logged-in
// linkedin.com tab so every recruiter uses THEIR OWN account (no shared cookie). ──
function _liStrHasOtw(s) {
  const lc = (s || '').toLowerCase();
  return ['open to work', 'opentowork', '#opentowork', 'open_to_work'].some(k => lc.includes(k));
}
function _liDeepHasOtw(obj, depth) {
  if (!obj || typeof obj !== 'object' || (depth || 0) > 5) return false;
  const t = obj.$type || '';
  if (['OpenToWork', 'Openness', 'OpenForOpportunities'].some(k => t.includes(k))) return true;
  for (const bf of ['openToWork', 'openToOpportunities', 'openToCareerOpportunities', 'isOpenToWork', 'openForOpportunities'])
    if (obj[bf] === true) return true;
  for (const key of ['overlayType', 'overlayImageType', 'text', 'badgeText', 'accessibilityText', 'overlayText', 'label', 'value'])
    if (_liStrHasOtw(String(obj[key] || ''))) return true;
  for (const v of Object.values(obj)) {
    if (v && typeof v === 'object' && !Array.isArray(v) && _liDeepHasOtw(v, (depth || 0) + 1)) return true;
    if (Array.isArray(v)) for (const it of v) if (it && typeof it === 'object' && _liDeepHasOtw(it, (depth || 0) + 1)) return true;
  }
  return false;
}
function parseLiVoyager(data, limit, location) {
  const included = (data && data.included) || [];
  const otwById = {};
  for (const obj of included) {
    if (!obj || typeof obj !== 'object') continue;
    const t = obj.$type || '';
    const nav = obj.navigationUrl || '';
    const m = nav.match(/\/in\/([\w-]+)/);
    const slug = (obj.publicIdentifier || obj.vanityName || (m ? m[1] : '') || '');
    if (slug && _liDeepHasOtw(obj, 0)) otwById[slug] = true;
  }
  const out = [], seen = new Set();
  for (const obj of included) {
    if (!obj || typeof obj !== 'object') continue;
    if (!String(obj.$type || '').includes('EntityResultViewModel')) continue;
    const name = ((obj.title && obj.title.text) || '').trim();
    if (!name || seen.has(name)) continue;
    seen.add(name);
    const headline = ((obj.primarySubtitle && obj.primarySubtitle.text) || '').trim();
    // The candidate's REAL location is in secondarySubtitle (e.g. "Hyderabad, Telangana, India").
    // Do NOT fall back to the job's search location — that mislabels everyone.
    const candLoc = ((obj.secondarySubtitle && obj.secondarySubtitle.text) || '').trim();
    const nav = obj.navigationUrl || '';
    const m = nav.match(/\/in\/([\w-]+)/);
    const pubId = m ? m[1] : '';
    let role = headline, company = '';
    const at = headline.match(/\s+(?:at|@)\s+/i);
    if (at) { role = headline.slice(0, at.index).trim(); company = headline.slice(at.index + at[0].length).trim(); }
    const otw = otwById[pubId] || _liStrHasOtw(headline);
    out.push({
      name, role, company, email: '', phone: '', salary: '',
      location: candLoc,
      linkedin: pubId ? `https://www.linkedin.com/in/${pubId}` : nav,
      public_url: pubId ? `https://www.linkedin.com/in/${pubId}` : nav,
      headline, skills: [], tags: [], source: 'linkedin', open_to_work: !!otw,
    });
    if (out.length >= (limit || 25)) break;
  }
  return out;
}
async function runLiRegularJob(tab, job) {
  const csrf = await liCsrfToken();
  if (!csrf) return { ok: false, error: 'no JSESSIONID (log into LinkedIn)' };
  const kw = encodeURIComponent(job.query || (job.params && job.params.title) || '');
  const url = 'https://www.linkedin.com/voyager/api/graphql' +
    '?variables=(start:0,origin:GLOBAL_SEARCH_HEADER,query:(keywords:' + kw +
    ',flagshipSearchIntent:SEARCH_SRP,queryParameters:List((key:resultType,value:List(PEOPLE))),' +
    'includeFiltersInResponse:false))' +
    '&queryId=voyagerSearchDashClusters.b0928897b71bd00a5a7291755dcd64f0';
  const headers = {
    'accept': 'application/vnd.linkedin.normalized+json+2.1',
    'csrf-token': csrf,
    'x-restli-protocol-version': '2.0.0',
    'x-li-lang': 'en_US',
    'x-li-page-instance': 'urn:li:page:d_flagship3_search_srp_people;1',
  };
  // executeScript can throw "Cannot access contents of the page" if the tab isn't a
  // loaded, permitted LinkedIn page yet. Re-ensure the tab and retry before failing.
  let r = null;
  await randDelay(2000, 5000);                        // human-like pause before searching
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: liPageGet, args: [url, headers] });
      r = res && res.result;
      if (r) break;
    } catch (e) {
      await log(`LinkedIn regular: tab not ready (${e.message}); reopening LinkedIn tab...`);
    }
    const t = await ensureLinkedInFeedTab();
    if (t) tab = t;
    await new Promise(rs => setTimeout(rs, 1500));
  }
  if (!r) return { ok: false, error: 'could not run LinkedIn search in tab (open/refresh a linkedin.com tab and retry)' };
  if (r.status === 401 || r.status === 403) return { ok: false, error: `LinkedIn ${r.status} (log into linkedin.com)` };
  if (!r.ok) return { ok: false, error: `LinkedIn voyager HTTP ${r.status}: ${(r.text || '').slice(0, 160)}` };
  let data; try { data = JSON.parse(r.text); } catch (e) { return { ok: false, error: 'bad JSON from LinkedIn voyager' }; }
  const loc = (job.params && job.params.location) || '';
  const candidates = parseLiVoyager(data, job.limit || 25, loc);
  return { ok: true, candidates, total: candidates.length };
}

// MAIN-world JSON POST (for create-project / batch-add). Returns {status, ok, text}.
function liPageJson(url, headers, bodyObj, methodOverride) {
  const h = Object.assign({ 'content-type': 'application/json; charset=UTF-8' }, headers);
  if (methodOverride) h['x-http-method-override'] = methodOverride;
  return fetch(url, { method: 'POST', credentials: 'include', headers: h, body: JSON.stringify(bodyObj) })
    .then(r => r.text().then(t => ({ status: r.status, ok: r.ok, text: t })))
    .catch(e => ({ status: 0, ok: false, text: String(e) }));
}

// Create a Recruiter project + add the top OTW candidates. Heavily logged so we
// can confirm the project's sourcing-channel + pipeline-state on first run.
async function runCreateProject(tab, job) {
  const ctx = await liSearchContext(tab, job);
  if (!ctx.ok) return ctx;
  const csrf = ctx.csrf;
  const baseHeaders = { 'accept': 'application/json', 'csrf-token': csrf, 'x-restli-protocol-version': '2.0.0' };

  // Paginate the recruiter search to collect EVERY matching profile (LinkedIn returns
  // ~25 per page) so the project gets all of them — not just the first page. CAP is a
  // safety ceiling so a huge search can't run away.
  const PAGE = 25, CAP = 1000;
  const picks = [];
  const seen = new Set();
  let candidates = [];
  let firstData = null, total = 0;
  for (let start = 0; start < CAP; start += PAGE) {
    const p = await liSearchPage(tab, job, ctx, start, PAGE);
    if (!p.ok) { if (start === 0) return p; break; }   // first-page error is fatal; later pages: stop
    if (!firstData) { firstData = p.data; total = (p.data.metadata || {}).total || 0; }
    const els = p.data.elements || [];
    if (!els.length) break;
    for (const e of els) {
      // entityUrn = urn:li:ts_hiring_candidate:(…,urn:li:ts_hire_identity:<id>)
      const m = String(e.entityUrn || '').match(/ts_hire_identity:(\d+)/);
      if (m) { const urn = 'urn:li:ts_hire_identity:' + m[1]; if (!seen.has(urn)) { seen.add(urn); picks.push(urn); } }
    }
    candidates = candidates.concat(parseLiElements(p.data, PAGE));
    if (total && start + PAGE >= total) break;          // fetched everything available
    if (els.length < PAGE) break;                        // last (partial) page
  }
  if (!firstData) return { ok: false, error: 'no results from recruiter search' };
  await log(`create-project: search total=${total}, collected ${picks.length} candidate ids across pages`);

  // 1) Create the project.
  const title = (job.params && job.params.title) || job.query || 'Scout Project';
  const meta = {
    name: title, rawTitleName: title, skills: [],
    state: 'ACTIVE', type: 'RECRUITER', projectVisibility: 'PRIVATE',
    hiringPipelineEnabled: false,
  };
  if (ctx.geo && ctx.geo.id) meta.geoLocationsUrns = ['urn:li:ts_geo:' + ctx.geo.id];
  const createBody = { attachDefaultCandidateHiringPipeline: true, hiringProjectMetadata: meta,
                       candidateCounts: [], approvalHistoryItems: [], customFieldValuesDecorated: [] };
  // decoration to (hopefully) get the project's sourcing channels back
  const createUrl = 'https://www.linkedin.com/talent/api/talentHiringProjects' +
    '?decoration=%28entityUrn%2CsourcingChannels*~%28entityUrn%2CchannelType%29%29';
  // Helper: one create attempt against a given URL.
  const tryCreate = async (url) => {
    const [c] = await chrome.scripting.executeScript({
      target: { tabId: tab.id }, world: 'MAIN', func: liPageJson, args: [url, baseHeaders, createBody, null] });
    return c && c.result;
  };
  // LinkedIn occasionally returns a transient 503/429/5xx on project creation.
  // Retry the create a few times with backoff before giving up.
  let cres = null;
  await randDelay(2000, 5000);                        // human-like pause before creating
  for (let attempt = 0; attempt < 4; attempt++) {
    cres = await tryCreate(createUrl);
    if (!cres || !cres.ok) cres = await tryCreate('https://www.linkedin.com/talent/api/talentHiringProjects'); // retry sans decoration
    if (cres && cres.ok) break;
    const st = cres ? cres.status : 0;
    if (!(st === 503 || st === 429 || st === 500 || st === 502 || st === 504 || st === 0)) break; // non-transient -> stop
    await log(`create-project: create ${st} (transient) — retrying in ${(attempt + 1) * 2}s`);
    await new Promise(r => setTimeout(r, (attempt + 1) * 2000));
  }
  if (!cres || !cres.ok) return { ok: false, error: `create project failed: ${cres ? cres.status + ' ' + cres.text.slice(0, 200) : 'no response'}` };
  await log(`create-project: create response ${cres.text.slice(0, 300)}`);
  let cdata; try { cdata = JSON.parse(cres.text); } catch (e) { return { ok: false, error: 'create project: bad JSON' }; }
  const projectUrn = cdata.entityUrn || (cdata.value && cdata.value.entityUrn) || '';
  if (!projectUrn) return { ok: false, error: 'create project: no entityUrn in response' };
  // contract + project id from urn:li:ts_hiring_project:(urn:li:ts_contract:<C>,<P>)
  const m = projectUrn.match(/ts_contract:(\d+),(\d+)\)/);
  const contract = m ? m[1] : '';
  const projectId = m ? m[2] : '';
  const projectUrl = projectId ? `https://www.linkedin.com/talent/hire/${projectId}` : '';
  await log(`create-project: created ${projectUrn}`);

  // 2) Find the project's sourcing channels (log all so we learn the recruiter-search type).
  let sourcingChannel = '';
  // Helper: pull the RECRUITER_SEARCH channel urn from a list of channels. Must NOT
  // match AUTOMATED_SOURCING / INTERNAL / APPLICANT (those 400 on candidate add).
  const pickChannel = (list) => {
    for (const c of list) {
      const urn = c.entityUrn || c.entity || (c.entityCountUnion && c.entityCountUnion.sourcingChannel) || '';
      if (urn) log(`  ch: ${urn} type=${c.channelType}`);
    }
    const rs = list.find(c => /^RECRUITER_SEARCH$/i.test(c.channelType || ''))
            || list.find(c => /RECRUITER_SEARCH/i.test(c.channelType || ''))
            || list.find(c => /MANUAL|RECRUITER/i.test(c.channelType || '') && !/AUTOMATED/i.test(c.channelType || ''))
            || list.find(c => !/INTERNAL|APPLICANT|AUTOMATED|REDISCOVER/i.test(c.channelType || ''))
            || list[0];
    return rs ? (rs.entityUrn || rs.entity || (rs.entityCountUnion && rs.entityCountUnion.sourcingChannel) || '') : '';
  };
  // Attempt A: GET the project with a sourcingChannels decoration.
  if (!sourcingChannel) {
    const gUrl = 'https://www.linkedin.com/talent/api/talentHiringProjects/' + encodeURIComponent(projectUrn) +
      '?altkey=urn&decoration=%28entityUrn%2CsourcingChannels*~%28entityUrn%2CchannelType%29%29';
    const [g] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: liPageGet, args: [gUrl, baseHeaders] });
    const gr = g && g.result;
    await log(`create-project: projGET ${gr ? gr.status : '?'} ${gr ? gr.text.slice(0, 300) : ''}`);
    if (gr && gr.ok) {
      try {
        const gd = JSON.parse(gr.text);
        // LinkedIn returns a resolution MAP keyed by channel urn, not an array.
        const map = gd.sourcingChannelsResolutionResults || gd.sourcingChannels;
        const list = Array.isArray(map) ? map : (map ? Object.values(map) : []);
        sourcingChannel = pickChannel(list);
      } catch (e) {}
    }
  }
  // Attempt B: the channels finder (log the full body incl. any 4xx so we learn the right params).
  if (!sourcingChannel) {
    const scUrl = 'https://www.linkedin.com/talent/api/talentSourcingChannels?q=hiringProject&count=25&hiringProject=' +
      encodeURIComponent(projectUrn);
    const [scr] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: liPageGet, args: [scUrl, baseHeaders] });
    const scres = scr && scr.result;
    await log(`create-project: channelsGET ${scres ? scres.status : '?'} ${scres ? scres.text.slice(0, 300) : ''}`);
    if (scres && scres.ok) {
      try {
        const sd = JSON.parse(scres.text);
        const list = sd.elements || (sd.data && sd.data.elements) || Object.values(sd.results || {});
        sourcingChannel = pickChannel(list);
      } catch (e) {}
    }
  }
  await log(`create-project: using sourcingChannel=${sourcingChannel || '(none found)'}`);

  // 3) Batch-add the candidates. This is a RestLi BATCH_CREATE — it MUST carry the
  //    x-restli-method: BATCH_CREATE header or LinkedIn 400s the {elements:[...]} body.
  //    Add in chunks so a large pool (hundreds) doesn't exceed batch limits.
  if (picks.length && sourcingChannel) {
    const addHeaders = Object.assign({}, baseHeaders, { 'x-restli-method': 'BATCH_CREATE' });
    const CHUNK = 100;
    let added = 0;
    for (let i = 0; i < picks.length; i += CHUNK) {
      if (i > 0) await randDelay(3000, 7000);        // human-like gap between add batches
      const elements = picks.slice(i, i + CHUNK).map(hid => ({
        hiringContext: projectUrn, candidate: hid, sourcingChannel,
        candidateAddedToANewProject: true, copiedFromAnotherProject: false,
      }));
      const [ar] = await chrome.scripting.executeScript({
        target: { tabId: tab.id }, world: 'MAIN', func: liPageJson,
        args: ['https://www.linkedin.com/talent/api/talentSourcingChannelCandidateCreations', addHeaders, { elements }, null] });
      const ares = ar && ar.result;
      if (ares && ares.ok) added += elements.length;
      await log(`create-project: add chunk ${i}-${i + elements.length} -> ${ares ? ares.status : '?'} ${ares ? ares.text.slice(0, 200) : ''}`);
    }
    await log(`create-project: added ${added}/${picks.length} candidates to project`);
  } else {
    await log('create-project: skipped add (no sourcingChannel or no candidates)');
  }

  // 4) Scrape email/phone only for the first batch we report back to Scout (visiting
  //    every profile would be far too slow for a large pool; the add is already done).
  await enrichLiContacts(tab, candidates.slice(0, 25));

  return { ok: true, candidates, project_url: projectUrl, total };
}

async function pollOnce() {
  const { scoutToken, scoutBase } = await getState();
  if (!scoutToken) { await log('No Scout login yet - open scout.volibits.com and sign in.'); return; }
  const base = (scoutBase || DEFAULT_BASE).replace(/\/$/, '');
  let jobs = [];
  try {
    const r = await fetch(base + '/api/naukri-agent/jobs', { headers: { 'Authorization': 'Bearer ' + scoutToken } });
    if (r.status === 401) { await log('Scout token expired - reopen scout.volibits.com.'); return; }
    if (!r.ok) { await log('Job fetch HTTP ' + r.status); return; }
    jobs = (await r.json()).jobs || [];
  } catch (e) { await log('Job fetch failed: ' + e.message); return; }
  if (!jobs.length) return;
  await log(`Got ${jobs.length} job(s) from Scout.`);

  for (const job of jobs) {
    try {
      const src = job.source || 'naukri';
      await log(`Running [${src}] "${job.query}" (id ${String(job.search_id).slice(0, 8)})`);
      let result;
      if (src === 'create_project') {
        const tab = await ensureLinkedInTab();
        if (!tab) { await postResults(job.callback_url, job.callback_token, job.search_id, [], 'no LinkedIn tab', null, src); await log('Could not open a LinkedIn tab.'); continue; }
        result = await runCreateProject(tab, job);
      } else if (src === 'linkedin_recruiter') {
        const tab = await ensureLinkedInTab();
        if (!tab) { await postResults(job.callback_url, job.callback_token, job.search_id, [], 'no LinkedIn tab', null, src); await log('Could not open a LinkedIn tab.'); continue; }
        result = await runLiJob(tab, job);
      } else if (src === 'linkedin_regular') {
        const tab = await ensureLinkedInFeedTab();
        if (!tab) { await postResults(job.callback_url, job.callback_token, job.search_id, [], 'no LinkedIn tab', null, src); await log('Could not open a LinkedIn tab.'); continue; }
        result = await runLiRegularJob(tab, job);
      } else {
        const tab = await ensureResdexTab();
        if (!tab) { await postResults(job.callback_url, job.callback_token, job.search_id, [], 'no Resdex tab', null, src); await log('Could not open a Resdex tab.'); continue; }
        result = await runJob(tab, job, await naukriCookies());
      }
      if (result.ok) {
        const status = await postResults(job.callback_url, job.callback_token, job.search_id, result.candidates, null, result.project_url, src);
        await log(`Sent ${result.candidates.length} candidate(s)${result.project_url ? ' + project ' + result.project_url : ''} -> ${status}`);
      } else {
        await postResults(job.callback_url, job.callback_token, job.search_id, [], result.error, null, src);
        await log('Job error: ' + result.error);
      }
    } catch (e) {
      await log('Job exception: ' + e.message);
    }
  }
}

// List this user's queued/in-flight jobs (without claiming them) for the popup.
async function listScoutJobs() {
  const { scoutToken, scoutBase } = await getState();
  if (!scoutToken) return [];
  const base = (scoutBase || DEFAULT_BASE).replace(/\/$/, '');
  try {
    const r = await fetch(base + '/api/naukri-agent/queued', { headers: { 'Authorization': 'Bearer ' + scoutToken } });
    if (!r.ok) return [];
    return (await r.json()).jobs || [];
  } catch (e) { return []; }
}

// Cancel (delete) this user's queued jobs on Scout. Returns count cleared.
async function clearScoutJobs() {
  const { scoutToken, scoutBase } = await getState();
  if (!scoutToken) return 0;
  const base = (scoutBase || DEFAULT_BASE).replace(/\/$/, '');
  try {
    const r = await fetch(base + '/api/naukri-agent/clear', { method: 'POST', headers: { 'Authorization': 'Bearer ' + scoutToken } });
    if (!r.ok) return 0;
    return (await r.json()).cleared || 0;
  } catch (e) { return 0; }
}

// Auto-cancel jobs left over from a previous session so they don't silently run
// when the browser/extension restarts.
async function cancelStaleOnStartup() {
  const n = await clearScoutJobs();
  if (n) await log(`Cancelled ${n} job(s) queued in a previous session.`);
}
chrome.runtime.onStartup.addListener(cancelStaleOnStartup);
chrome.runtime.onInstalled.addListener(cancelStaleOnStartup);

chrome.alarms.onAlarm.addListener((a) => { if (a.name === POLL_ALARM) pollOnce(); });

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'start-polling') {
    chrome.alarms.create(POLL_ALARM, { periodInMinutes: 0.5 });
    setState({ polling: true });
    log('Polling started (every 30s).');
    pollOnce();
    sendResponse({ ok: true });
  } else if (msg.type === 'stop-polling') {
    chrome.alarms.clear(POLL_ALARM);
    setState({ polling: false });
    log('Polling stopped.');
    sendResponse({ ok: true });
  } else if (msg.type === 'poll-now') {
    pollOnce().then(() => sendResponse({ ok: true }));
    return true;
  } else if (msg.type === 'list-jobs') {
    listScoutJobs().then((jobs) => sendResponse({ jobs }));
    return true;
  } else if (msg.type === 'cancel-jobs') {
    clearScoutJobs().then((cleared) => { log(`Cancelled ${cleared} queued job(s).`); sendResponse({ cleared }); });
    return true;
  }
});
