// Runs in the resdex.naukri.com tab. The actual search now runs from the
// background via chrome.scripting (MAIN world), so this script only reports
// login status for the popup.

function isLoggedIn() {
  const u = location.href.toLowerCase();
  if (u.includes('/login') || u.includes('recruit.naukri.com')) return false;
  return u.includes('resdex.naukri.com');
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'ping') {
    sendResponse({ loggedIn: isLoggedIn(), url: location.href });
    return true;
  }
});
